public class Image {
	private int W, H;
	private int [] pixels;
	
	public Image(String ppmFileName) {			// CSE274 - don't change this method
		Object [] result;
		try {
			result = PPM_IO.read(ppmFileName);
		}
		catch (Exception e) {
			throw new IllegalArgumentException("Problem reading file: " + ppmFileName);
		}
		W = (Integer)result[0];
		H = (Integer)result[1];
		pixels = (int[])result[2];
	}
	
	/**
	 * @param width, height and default brightness
	 * This is a constructor to make images
	 */
	public Image(int width, int height, int defaultBrightness) {
		
		W = width;
		H = height;
		pixels = new int [W * H];
		
		for(int i = 0; i < pixels.length-1; i++) {
			pixels[i]=defaultBrightness;
		}
		
	}
	
	/**
	 * 
	 * This is a getter to find the images width
	 * @return the width of the image
	 * 
	 */
	public int getWidth(){
		
		return this.W;
		
	}
	
	/**
	 * 
	 * This is a getter to find the images Height
	 * @return the Height of the image
	 * 
	 */
	public int getHeight(){
		
		return this.H;
		
	}
	
	
	/**
	 * 
	 * This is a getter to find the images pixel brightness
	 * @return the brightness of a pixel
	 * @param int x and int y (x and y of original image)
	 * 
	 */
	public int getPixel(int x, int y) {
		
		int brightness = 0;
		int index = index( x , y );
		for(int i = 0; i < pixels.length-1; i++) {
			brightness = pixels[index];
		}
		
		return brightness;
		
	}
	
	
	/**
	 * 
	 * This is a setter to set the images pixel brightness
	 * @param int x , int y and brightness (x and y of original image and the brightness)
	 * 
	 */
	public void setPixel(int x, int y, int brightness) {
		
		int index = index( x , y );
			pixels[index] = brightness;
	}
	
	
	/**
	 * 
	 * This is an index for looping through the image, keeps track of location
	 * @param int x , int y
	 * 
	 */
	public int index(int x, int y) {
		
		int index = ( y * W ) + x;
		return index;
		
	}
	
	/**
	 * 
	 * This is a method used to darken the image
	 * @return a darkened image called result
	 * 
	 */
	public Image darken() {
		
		Image result = new Image(W,H,255);
		for(int i = 0; i < W; i++) {
			for(int j = 0; j < H; j++) {
				result.setPixel(i,j, this.getPixel(i,j)/2);
			}
		}
		return result;
	}
	
	/**
	 * 
	 * This is a method used to lighten the image
	 * @return a lightened image called result
	 * 
	 */
	public Image lighten() {
		
		Image result = new Image(W,H,255);
		for(int i = 0; i < W; i++) {
			for(int j = 0; j < H; j++) {
				if(this.getPixel(i,j)*2 <= 255) {result.setPixel(i,j, this.getPixel(i,j)*2);}else{result.setPixel(i,j,255);};
			}
		}
		return result;
		
	}
	
	/**
	 * 
	 * This is a method used to flip the image upside down
	 * @return an upside down version of the photo, returned as result
	 * 
	 */
	public Image flipVertically() {
		Image result = new Image(W,H,255);
		for(int i = 0; i < W; i++) {
			for(int j = 0; j < H; j++) {
				result.setPixel(i,j, this.getPixel(i,H-j-1));
			}
		}
		return result;
		
	}
	
	/**
	 * 
	 * This is a method used to change the brightness and posterized the photo given
	 * the number of brightnesses the photo should be divided into
	 * 
	 * @param int numBrightnesses  (how many brightness groups the pixels can be divided into)
	 * @return a posterized image
	 * 
	 */
	public Image posterize(int numBrightnesses) {
		
		Image result = new Image(W,H,255);
		
		int brightLevel = 256/numBrightnesses;
		
		int low = brightLevel;
		int high = brightLevel + brightLevel;
		for(int i = 0; i < pixels.length; i++) {
			if(pixels[i] >=low && pixels[i] <= high) {
				result.pixels[i] = low;
			}	
		}
		return result;
		
	}
	
	
	/**
	 * 
	 * This is a method used to soften the surrounding pixels in a photo
	 * it works by being given the information of an original image and 
	 * using that to create a new soft image
	 * @return a softer version of the image
	 * 
	 */
	public Image soften() {
		return this;
	}
	
	/**
	 * 
	 * This is a method used to merge two different photos together side by size
	 * 
	 * @param Image im1(regular image) and Image im2(posterized image)
	 * @return a single photo with the two specified photos side by side
	 * 
	 */
	public Image horizontalMerge(Image im1, Image im2) {
		
		Image result = new Image(W,H,255);
		if(im1.H==im2.H) {
			for(int i = 0; i < H; i++) {
				for(int j = 0; j < W/2; j++) {
					result.setPixel(j,i, im1.getPixel(j,i));
				}
				for(int j = W/2; j < W; j++) {
					result.setPixel(j,i, im2.getPixel(j,i));
				}
			}
		}
		return result;
		
	}
	
	
	
	public void display(String title) {			// CSE274 - don't change this method
		new ImageFrame(pixels, W, H, title);
	}
	public void display() {						// CSE274 - don't change this method
		display("no title");
	}
	public void write(String fname) {			// CSE274 - don't change this method
		try {
			PPM_IO.write(fname, W, H, pixels);
		}
		catch (Exception e) {
			throw new IllegalArgumentException("Problem writing to file: " + fname);
		}
	}
	
	
	/**
	 * 
	 * This is a method used to create a new image the same as the original but with a border
	 * 
	 * @param int borderWidth (the width of the border) and int borderColor (determines the brightness of pixel)
	 * @return an mage the same as the origional but has a specified border around it
	 * 
	 */
	public Image addBorder(int borderWidth, int borderColor) {
		
		Image result = new Image(W + (2 * borderWidth),H + (borderWidth * 2),borderColor);
		
		for (int i = 0; i < W + (borderWidth); i++) {
		      for (int j = 0; j < H + (borderWidth); j++) {
		         if (i > borderWidth && i < W + (borderWidth) && j > borderWidth && j < H + (borderWidth)){
		        	 	result.setPixel(i,j, this.getPixel(i - (borderWidth),j - (borderWidth)));
		         } else {
		        	 	result.setPixel(i,j, borderColor);
		         }
		      }
		   }
		
		return result;
	}
	
}
