// CSE 274: You don't need to change this file.

import java.awt.*;
import javax.swing.*;

public class ImageFrame extends JFrame {
	public static final int B = 75;
	
	class DrawPane extends JPanel {
		private static final long serialVersionUID = 1L;
		
		public void paintComponent(Graphics g) {
			int i = 0;
			for (int y = H-1; y >= 0; y--) {
				for (int x = 0; x < W; x++, i++) {
					Color C = new Color(pixels[i], pixels[i], pixels[i]);
					g.setColor(C);
					g.fillRect(x+1, y+1, 1, 1);
				}
			}
			g.setColor(Color.GREEN);
			g.drawRect(0, 0, W+1, H+1);
		}
	}
	
	private static final long serialVersionUID = 1L;
	private int [] pixels;
	private int W, H;

	public ImageFrame(int [] pixs, int width, int height, String title) {
		super(title);
		pixels = pixs;
		W = width;
		H = height;
		setContentPane(new DrawPane());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(W + B, H + B);
		setVisible(true);
	}
}