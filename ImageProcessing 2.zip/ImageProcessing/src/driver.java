import java.io.*;
/**
*Parts of Project working correctly (Darken, Lighten, Flip Vertically, Add Border
*
*
*Parts not working correctly (Horizontal Merge-Both images don't display but merges 2 photos and splits them)
*(Posterize-unable to get the correct shading for the image)
*(Sub Image-collects an image of the size specified but unable to gather image)
*(Soften-unable to complete in time)
*
*/
public class driver {
	public static void main(String [] args) throws FileNotFoundException {
		Image im = new Image("mu.ppm");
		im.display("original image");
		
		//returns darkened image
		Image dark =  im.darken();
		dark.display("Dark image");
		
		//returns lightened image
		Image light =  im.lighten();
		light.display("light image");
		
		//returns 2 images merged together
		Image merge =  im.horizontalMerge(im,im.posterize(8));
		merge.display("Merge image");
		
		//returns a softened image
		Image soft =  im.soften();
		soft.display("soft image");
		
		//returns a upsidedown photo
		Image flip =  im.flipVertically();
		flip.display("flipped image");
		
		//returns a posterized photo
		Image poster =  im.posterize(8);
		poster.display("Poster image");
		
		
		//returns the image with a border with the brightness of choice
		Image border = im.addBorder(10, 128);
		border.display("border");
		border.write("muborder.ppm");
	}
}
