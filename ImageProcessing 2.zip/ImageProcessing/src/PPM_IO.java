// CSE 274: You don't need to change this file.

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class PPM_IO {
	public static void write(String fname, int W, int H, int [] pixels) throws FileNotFoundException {
		PrintWriter sw = new PrintWriter(new File(fname)); 
		sw.println("P3");
		sw.println("# Created by CSE 274 Image class software");
		sw.println(W + " " + H);
		sw.println("255");
		for (int row = H-1; row >= 0; row--) {		// stored top to bottom
			int i = row * W;
			for (int col = 0; col < W; col++, i++) {
				int B = pixels[i];
				sw.println(B + " " + B + " " + B);
			}
		}
		sw.close();
	}
	private static Object [] p3(Scanner input) {
		int W = input.nextInt();
		int H = input.nextInt();
		int [] pixels = new int [W*H];
		
		input.nextLine();
	
		input.nextInt();	// max value is not used.
		
		for (int row = H-1; row >= 0; row--) {		// stored top to bottom
			int i = row * W;
			for (int col = 0; col < W; col++, i++) {
				int R = input.nextInt();
				int G = input.nextInt();
				int B = input.nextInt();
				pixels[i] = (R+G+B)/3;
			}
		}
		return new Object [] { new Integer(W), new Integer(H), pixels };
	}
	public static Object [] read(String ppmFileName) throws FileNotFoundException {
		String header = null;
		Scanner input = null;
		Object [] result = { null, null, null };
		try {
			input = new Scanner(new File(ppmFileName));
			header = input.nextLine();
	
			input.nextLine();	// assume one comment line
			
			if (header.indexOf("P3") == 0) {
				result = p3(input);
			} else {
				System.err.println("Problem with PPM file: " + ppmFileName + "(" +  header + ")");
			}
		}
		catch (Exception e) {
			System.err.println("Problem with PPM file: " + ppmFileName + "(" +  header + ")");
			throw e;
		}
		finally {
			if (input != null)
				input.close();
		}
		return result;
	}
	
	
}
