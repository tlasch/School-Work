import TreePackage.*;
import java.util.*;

public class Driver {

	public static void displayTree(Iterator<Integer> iter) {
		while (iter.hasNext()) {
			System.out.print(iter.next() + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		BinaryTree<Integer> bt1 = new BinaryTree<>(10, null, null);
		BinaryTree<Integer> bt2 = new BinaryTree<>(-12, null, null);
		BinaryTree<Integer> bt3 = new BinaryTree<>(10, bt1, bt2);
		BinaryTree<Integer> bt4 = new BinaryTree<>(1, null, null);
		BinaryTree<Integer> btExtra = new BinaryTree<>(1, null, null);
		BinaryTree<Integer> bt5 = new BinaryTree<>(100, btExtra, bt4);
		BinaryTree<Integer> bt6 = new BinaryTree<>();
		bt6.setTree(1000, bt3, bt5); // don't use bt3 and bt5 below here.
		BinaryTree<Integer> tree = bt6;
		System.out.println("\nPreorder");
		displayTree(tree.getPreorderIterator());
		tree.recursivePreorderTraversal();
		tree.iterativePreorderTraversal();
		
		System.out.println("\nPostorder");
		displayTree(tree.getPostorderIterator());
		tree.iterativePostorderTraversal();
		tree.recursivePostorderTraversal();

		System.out.println("\nInorder");
		displayTree(tree.getInorderIterator());
		tree.iterativeInorderTraversal();
		tree.recursiveInorderTraversal();

		System.out.println("\nLevelorder");
		displayTree(tree.getLevelOrderIterator());
		tree.iterativeLevelorderTraversal();
		
		System.out.println("\nTree info");
		System.out.println("Num nodes: " + tree.getNumberOfNodes());
		System.out.println("Num leaves: " + tree.getNumberOfLeaves());
		System.out.println("Leaves: " + tree.getLeaves());
		System.out.println("Max: " + tree.max());
		System.out.println("Complete?: " + tree.isCompleteTree());
		System.out.println("Full?: " + tree.isFullTree());
		System.out.println("Balanced?: " + tree.isBalancedTree());
		System.out.println("BST?: " + tree.isBST());
		System.out.println("Max Heap?: " + tree.isMaxHeap());
		System.out.println("Num Copies is " + tree.numCopies(10));
	}
}
