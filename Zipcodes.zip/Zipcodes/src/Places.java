import java.util.*;
import java.io.*;

public class Places {
	private ArrayList<Location> places;

	public Places(String fname) throws FileNotFoundException {
		places = new ArrayList<>();
		Scanner input = null;
		input = new Scanner(new File(fname));
		input.nextLine(); // skip first line
		while (input.hasNextLine()) {
			String[] toks = input.nextLine().split("\t", -1);
			Location loc = new Location(toks);
			places.add(loc);
		}
		input.close();
	}	

	/**
	 * Returns all state names in the entire database
	 * 
	 * @return set of state names
	 */
	public Set<String> allStateNames() {
		Set<String> result = new TreeSet<String>();
		//goes through all locations and adds a new state
		for(Location loc : places) {
			result.add(loc.state);
		}
		return result;
	}
	
	/**
	 * Returns all city names in the entire database
	 * 
	 * @return set of city names
	 */
	public Set<String> allCityNames() {
		Set<String> result = new TreeSet<String>();
		//goes through all locations and adds a new state
		for(Location loc : places) {
			result.add(loc.state);
		}
		return result;
	}
	
	/**
	 * Returns all the states that contain a particular city name. The empty set
	 * is returned if the city name is not any state.
	 * 
	 * @param cityName
	 *            target city name
	 * @return set of states that contain the target city.
	 */
	public Set<String> getStatesThatContainThisCity(String cityName) {
		Set<String> result = new TreeSet<>();
		for(Location loc : places) {
			if(loc.cityName.equals(cityName))
			result.add(loc.state);
		}
		return null;
	}

	/**
	 * Returns all city names that reside within a particular state.
	 * 
	 * @param state
	 *            target state
	 * @return set of city names
	 */
	public Set<String> allCityNames(String state) {
		Set<String> result = new TreeSet<>();
		for(Location loc : places) {
			if(loc.state.equals(state)) {
				result.add(loc.cityName);
			}
		}
		return result;
	}

	/**
	 * Returns all city names that reside within any of the given states.
	 * 
	 * @param state
	 *            target states
	 * @return set of city names
	 */
	public Set<String> allCityNames(Set<String> states) {
		Set<String> result = new TreeSet<>();
		for(Location loc : places) {
			if(states.contains(loc.state)) {
				result.add(loc.cityName);
			}
		}
		return result;
	}

	/**
	 * Returns the states that contain any of the target cities. The empty set
	 * is returned if none of the cities are in any state. This is similar to
	 * above but accepts multiple cities instead of single city.
	 * 
	 * @param cityNames
	 *            target cities
	 * @return set of states that contain any of the target cities.
	 */
	public Set<String> getStatesThatContainAnyOfTheseCities(Set<String> cityNames) {
		Set<String> result = new TreeSet();
		
		return null;
	}

	/**
	 * Returns the city names that appear in both of the given states
	 * 
	 * @param state1
	 *            first target state
	 * @param state2
	 *            second target state
	 * @return set of city names
	 */
	public Set<String> getCommonCityNames(String state1, String state2) {
		Set<String> citiesState1 = allCityNames(state1);
		Set<String> citiesState2 = allCityNames(state2);
		Set<String> result = new TreeSet<>();
		for(String c1 : citiesState1) {
			if(citiesState2.contains(c1)) {
				result.add(c1);
			}
		}
			return result;
	}
	
	/**
	 * Returns all the city names that correspond to a particular zipcode. The
	 * empty set is returned if the zipcode is not valid.
	 * 
	 * @param zipCode
	 *            target zip code
	 * @return set with all city names with the target zip code.
	 */
	public Set<String> getCityNameFromZipCode(int zipCode) {
		return null;
	}

	/**
	 * Returns all the zipcodes that are contained in a particular city-state.
	 * The empty set is returned if the city-state pair is illegal.
	 * 
	 * @param cityName
	 *            target city name
	 * @param state
	 *            target state
	 * @return set with all relevant zipcodes.
	 */
	public Set<Integer> getZipCodes(String cityName, String state) {
		Set<Integer> result = new TreeSet<Integer>();
		for(Location loc : places) {
			if(loc.state.equals(state) && loc.cityName.equals(cityName)) {
				result.add(loc.zipCode);
			}
		}
		
		
		return result;
	}
	
	
	
	//returns all a states zip codes
	public Set<Integer> getStateZipCodes(String state) {
		Set<Integer> result = new TreeSet<Integer>();
		for(Location loc : places) {
			if(loc.state.equals(state)) {
				result.add(loc.zipCode);
			}
		}
		
		
		return result;
	}
	




	/**
	 * Returns a map that is keyed to state name. The values in the map are the
	 * set of city names that reside in that particular state. The map looks
	 * like: "AL" --> { "MONTGOMERY", "MOBILE", ... } "AK" --> { "ANCHORAGE",
	 * "BARROW", ...} ...
	 * 
	 * @return mapping from states to set of city names.
	 */
	public Map<String, Set<String>> getCityNames() {
		return null;
	}
	
	/**
	 * Returns a map that is keyed to state name. The values in the map is a set
	 * of zip codes that reside in that particular state. The map looks like:
	 * "AL" --> { 36863, 35755, ... } "AK" --> { 44256, 44257, ...} ...
	 * 
	 * @return mapping from states to set of zipcodes.
	 */
	public Map<String, Set<Integer>> getZipCodesInStates() {
		Map<String, Set<Integer>> result = new HashMap <String, Set<Integer>>();
		Set<String> stateNames = allStateNames();
		for(String state : stateNames) {
			result.put(state, getStateZipCodes(state));
		}
		return result;
	}

	/**
	 * Returns all zipcodes that are within a specified distance from a
	 * particular zipcode.
	 * 
	 * @param zipCode
	 *            target zipcode
	 * @param distance
	 *            maximum distance from target zipcode
	 * @return all zipcodes that are within "distance" from the target zipcode
	 */
	public Set<Integer> getZipCodesCloseTo(int zipCode, double distance) {
		Set<Integer> latsAndLong = new TreeSet<Integer>();
		for(int zipcode : latsAndLong) {
		}
		
		
		return null;
	}
	
	
    public static double haversine(double lat1, double lon1, double lat2, double lon2) {
    		final double R = 6372.8;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        lat1 = Math.toRadians(lat1);
        lat2 = Math.toRadians(lat2);
 
        double a = Math.pow(Math.sin(dLat / 2),2) + Math.pow(Math.sin(dLon / 2),2) * Math.cos(lat1) * Math.cos(lat2);
        double c = 2 * Math.asin(Math.sqrt(a));
        return R * c;
    }

	/**
	 * Ranked list of states, where the ranking is ascending order of number of
	 * zipcodes.
	 * 
	 * @return
	 */
	public ArrayList<String> mostZipCodes() {
		return null;
	}

	/**
	 * The city name(s) that appears in the most states. Note, "NEW YORK" is
	 * credited with appearing in NY only once. That is, the large number of
	 * "NEW YORK" zipcodes does not make it a more common name.
	 * 
	 * @return set of city names
	 */
	public Set<String> cityNameInMostStates() {
		return null;
	}
	
	public static <T> void display(PrintWriter output, Set<T> items) {
		if (items == null) {
			output.println("null");
			return;
		}
		int LEN = 80;
		String line = "[";
		for (T item : items) {
			line += item.toString() + ",";
			if (line.length() > LEN) {
				output.println(line);
				line = "";
			}
		}
		output.println(line + "]");
	}

	public static <K, V> void display(PrintWriter output, Map<K, Set<V>> items) {
		if (items == null) {
			output.println("null");
			return;
		}
		for (K key : items.keySet()) {
			output.println(key + "---------->");
			display(output, items.get(key));
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("STARTING");

		PrintWriter output = new PrintWriter(new File("output.txt"));
		Places places = new Places("ZipCodes.txt");
		
		Set<String> states = new TreeSet<String>();
		states.add("OH");
		states.add("MI");
		Set<String> cities = new TreeSet<String>();
		cities.add("OXFORD");
		//display(output, places.allStateNames());
		//display(output, places.allCityNames());
		//display(output, places.allCityNames("HI"));
		//display(output, places.allCityNames(states));
		//System.out.println("Break---------------------------------");
		display(output, places.getCommonCityNames("MI", "OH"));
//		display(output, places.getStatesThatContainThisCity("OXFORD"));
//		display(output, places.getStatesThatContainAnyOfTheseCities(cities));
//		display(output, places.getCityNameFromZipCode(45056));
		display(output, places.getZipCodesInStates());
//		display(output, places.getCityNames());
//		display(output, places.cityNameInMostStates());
//		System.out.println(places.mostZipCodes());
//		display(output, places.getZipCodes("CLEVELAND", "OH"));
//		display(output, places.getStateZipCodes("OH"));
//		display(output, places.getZipCodes("OXFORD", "OH"));
//		display(output, places.getZipCodes("RICHMOND", "IN"));
		output.close();
		System.out.println("DONE!");
	}
}
