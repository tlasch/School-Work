import static org.junit.Assert.*;

import org.junit.Test;

public class LinkedDequeTest {

	@Test
	public void testClear() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		myDeque.addToBack("Mike");
		assertFalse(myDeque.isEmpty());
		myDeque.clear();
		assertTrue(myDeque.isEmpty());
	}

	@Test
	public void addToBack() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		myDeque.addToBack("Mike");
		assertTrue(myDeque.getBack().equalsIgnoreCase("Mike"));
		myDeque.addToBack("Dave");
		assertTrue(myDeque.getBack().equalsIgnoreCase("Dave"));
	}
	
	@Test
	public void addToFront() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		myDeque.addToFront("Mike");
		assertTrue(myDeque.getFront().equalsIgnoreCase("Mike"));
		myDeque.addToFront("Dave");
		assertTrue(myDeque.getFront().equalsIgnoreCase("Dave"));
	}
	
	
	@Test
	public void getFront() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		myDeque.addToFront("Mike");
		assertTrue(myDeque.getFront().equalsIgnoreCase("Mike"));
		myDeque.addToFront("Dave");
		assertTrue(myDeque.getFront().equalsIgnoreCase("Dave"));
	}
	
	@Test
	public void getBack() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		myDeque.addToBack("Mike");
		assertTrue(myDeque.getBack().equalsIgnoreCase("Mike"));
		myDeque.addToBack("Dave");
		assertTrue(myDeque.getBack().equalsIgnoreCase("Dave"));
	}
	
	@Test
	public void removeFront() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		myDeque.addToFront("Mike");
		assertTrue(myDeque.removeFront().equalsIgnoreCase("Mike"));
		myDeque.addToFront("Mike");
		myDeque.addToFront("Dave");
		assertTrue(myDeque.removeFront().equalsIgnoreCase("Dave"));
	}
	
	@Test
	public void removeBack() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		myDeque.addToBack("Mike");
		assertTrue(myDeque.removeBack().equalsIgnoreCase("Mike"));
		myDeque.addToBack("Mike");
		myDeque.addToBack("Dave");
		assertTrue(myDeque.removeBack().equalsIgnoreCase("Dave"));
	}
	
	@Test
	public void isEmpty() {
		DequeInterface<String> myDeque = new LinkedDeque<>();
		assertTrue(myDeque.isEmpty());
		myDeque.addToBack("Mike");
		assertFalse(myDeque.isEmpty());
		myDeque.clear();
		assertTrue(myDeque.isEmpty());
	}
	
	
}
