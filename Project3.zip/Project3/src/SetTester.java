import static org.junit.Assert.*;

import java.awt.Point;

import org.junit.Test;

public class SetTester {

	@Test
	public void testGetSize() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		//expected number of entries is 0 and we get that result
		assertEquals(0,ras1.getSize());
		Point p1 = new Point(3, 0);
		ras1.add(p1);
		//expected number of entries is 1 and we get that result of one
		assertEquals(1,ras1.getSize());
		
		
		//creating points
		Point p2 = new Point(4, 1);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
		
		//adding points to array
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		
		//expected number of entries is 4 and we get that result of 4
		assertEquals(4,ras1.getSize());
		
	}
	
	
	
	@Test
	public void testIsEmpty() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		assertEquals(0,ras1.getSize());
		//tests that an empty array has 0 entries and is empty
		assertTrue(ras1.isEmpty());
		Point p1 = new Point(3, 0);
		ras1.add(p1);
		assertEquals(1,ras1.getSize());
		//added one point to the array and it is no longer empty
		assertFalse(ras1.isEmpty());
	}

	@Test
	public void testAdd() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		//adding to empty
		Point p1 = new Point(3, 0);
		assertTrue(ras1.add(p1));
		assertEquals(1,ras1.getSize());
		assertTrue(ras1.contains(p1));
		
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
		Point p5 = new Point(7, 4);
		Point p6 = new Point(8, 5);
		Point p7 = new Point(9, 6);
		Point p8 = new Point(10, 7);
		Point p9 = new Point(11, 8);
		Point p10 = new Point(12, 9);
		
		//adding up to 10
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		ras1.add(p5);
		ras1.add(p6);
		ras1.add(p7);
		ras1.add(p8);
		ras1.add(p9);
		ras1.add(p10);
		//checking that size changes after 10
		assertEquals(10, ras1.getSize());
		
		Point p11 = new Point(13, 10);
		Point p12 = new Point(14, 11);
		
		//Tests the feature of doubling the array after adding a point that is beyond the default
		//array size. Expected size is 20 because 10 * 2 is 20.
		ras1.add(p11);
		assertEquals(20, ras1.getLength());
		ras1.add(p12);
		assertEquals(20, ras1.getLength());
	}
	
	@Test
	public void testRemovePoint() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		//nothing to remove
		//creating points to add
		Point p1 = new Point(3, 0);
		//removing point that doesnt exist doesnt work
		assertFalse(ras1.remove(p1));
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
	
		//adding points to array
		ras1.add(p1);
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		//removes p1 as expected
		assertTrue(ras1.remove(p1));
		//cant remove already removed point
		assertFalse(ras1.remove(p1));
		//removes p3 as expected
		assertTrue(ras1.remove(p3));
		//properly shrinks in size as expected to 5
		assertEquals(5, ras1.getLength());
		
	}
	
	
	@Test
	public void testRemove() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		//nothing to remove
		assertEquals(null,ras1.remove());
		//adding to empty
		Point p1 = new Point(3, 0);
		assertTrue(ras1.add(p1));
		//making sure it is added
		assertEquals(1,ras1.getSize());
		assertTrue(ras1.contains(p1));
		
		//tests the size being cut in half if the number of entries is less than
		//1/3 of the length of the array
		assertEquals(p1,ras1.remove());
		assertEquals(5, ras1.getLength());
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
	
		//adding points to array
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		
		//checking that the expected last value is removed
		//p4 is removed
		assertEquals(p4,ras1.remove());
		//p3 is removed
		assertEquals(p3,ras1.remove());
		
	}
	
	
	@Test
	public void testClear() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
		//testing clearing an empty array
		ras1.clear();
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
		
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
		
		//adding points to array
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		
		//testing clearing a filled array
		ras1.clear();
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
	}
	
	@Test
	public void testContains() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
		Point p2 = new Point(4, 1);
		//testing contains on a point not in the array
		assertFalse(ras1.contains(p2));
		ras1.add(p2);
		
		//testing contains on an array with 1 point
		assertTrue(ras1.contains(p2));
		
		//creating points to add
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
		
		//adding points to array
		ras1.add(p3);
		ras1.add(p4);
		
		//testing contains on a point p4 also in the array
		assertTrue(ras1.contains(p4));
		
	}
	
	
	@Test
	public void testUnion() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
		
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(22, 2);
		Point p4 = new Point(11, 0);
		Point p9 = new Point(4, 1);
		
		//adding points to array
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		ras1.add(p9);
		
		ResizableArraySet ras2 = new ResizableArraySet();	
		
		//creating points to add
		Point p6 = new Point(11, 0);
		Point p7 = new Point(8, 9);
		Point p8 = new Point(4, 1);
		
		//adding points to array
		ras2.add(p6);
		ras2.add(p7);
		ras2.add(p8);
		
		//testing to see if the union contains all mutual points
		//does not work however
		assertTrue(ras1.union(ras2).contains(p2));
		assertTrue(ras1.union(ras2).contains(p3));
		assertTrue(ras1.union(ras2).contains(p4));
		assertTrue(ras1.union(ras2).contains(p6));
		assertTrue(ras1.union(ras2).contains(p7));
		assertTrue(ras1.union(ras2).contains(p8));
		
	}
	
	@Test
	public void testIntersection() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
		
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(22, 2);
		Point p4 = new Point(11, 0);
		Point p9 = new Point(4, 1);
		
		//adding points to array
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		ras1.add(p9);
		
		ResizableArraySet ras2 = new ResizableArraySet();	
		
		//creating points to add
		Point p6 = new Point(11, 0);
		Point p7 = new Point(8, 9);
		Point p8 = new Point(4, 1);
		
		//adding points to array
		ras2.add(p6);
		ras2.add(p7);
		ras2.add(p8);
		
		//tests to see that the intersection point p2 which is in both arrays
		//is returned
		assertTrue(ras1.intersection(ras2).contains(p2));
		//tests to see that the intersection point p3 which is in both arrays
		//is not contained in the return array
		assertFalse(ras1.intersection(ras2).contains(p3));
		//tests to see that the intersection point p6 which is in both arrays
		//is returned as in the combined array
		assertTrue(ras1.intersection(ras2).contains(p6));
	}
	
	@Test
	public void testDifference() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
		
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
		Point p9 = new Point(4, 1);
		
		//adding points to array
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		ras1.add(p9);
		
		ResizableArraySet ras2 = new ResizableArraySet();	
		
		//creating points to add
		Point p6 = new Point(11, 0);
		Point p7 = new Point(5, 2);
		Point p8 = new Point(4, 1);
		
		//adding points to array
		ras2.add(p6);
		ras2.add(p7);
		ras2.add(p8);
		
		//the new array does not have the point that is in both arrays p2
		assertFalse(ras1.difference(ras2).contains(p2));
		//the new array has the point that is not in both arrays p6
		assertTrue(ras2.difference(ras1).contains(p6));
	}
	
	
	//unsure how to test toArray
	@Test
	public void testToArray() {
		ResizableArraySet ras1 = new ResizableArraySet();	
		assertEquals(0,ras1.getSize());
		assertTrue(ras1.isEmpty());
		
		//creating points to add
		Point p2 = new Point(4, 1);
		Point p3 = new Point(5, 2);
		Point p4 = new Point(6, 3);
		Point p9 = new Point(4, 1);
		
		//adding points to array
		ras1.add(p2);
		ras1.add(p3);
		ras1.add(p4);
		ras1.add(p9);
		
//		assertTrue(ras1.toArray().contains(p2));
		
	}

}
