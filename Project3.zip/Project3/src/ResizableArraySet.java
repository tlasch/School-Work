import java.awt.Point;
import java.util.Arrays;

public class ResizableArraySet implements SetInterface {

	
	Point[] rArray;
	int numberOfEntries;
	private static final int DEFAULT_CAPACITY = 10;
	
	
	public ResizableArraySet() {
		this(DEFAULT_CAPACITY);
	}
	
	public ResizableArraySet(int desiredCapacity) {
		rArray = new Point[desiredCapacity];
		numberOfEntries = 0;
	}
	
	@Override
	public int getSize() {
		return numberOfEntries;
	}
	
	
	
	//used to test the length of the array for when changing sizes by adding and removing
	public int getLength() {
		return rArray.length;
	}
	

	@Override
	public boolean isEmpty() {
		return numberOfEntries==0;
	}

	@Override
	public boolean add(Point newValue) {
		//resizes the array if adding a value makes number of entries > the arrays length
		if(numberOfEntries + 1 == rArray.length) {
			rArray = Arrays.copyOf(rArray, rArray.length * 2);
			rArray[numberOfEntries] = newValue;
			numberOfEntries++;
		} else {
			rArray[numberOfEntries] = newValue;
			numberOfEntries++;
		}
		return true;
	}

	@Override
	public boolean remove(Point aValue) {
		if(isEmpty()) {
			return false;
		} else {
			for(int i=0; i< numberOfEntries; i++) {
				if(rArray[i].equals(aValue)){
					rArray[i] = rArray[numberOfEntries-1];
					rArray[numberOfEntries-1] = null;
					numberOfEntries--;
					//shrinks array
					if(numberOfEntries <= rArray.length/3) {
						rArray = Arrays.copyOf(rArray, rArray.length / 2);
					}
					return true;
				}
			}
		}return false;
	}
	
	

	@Override
	public Point remove() {
		Point removedPoint = null;
		if(isEmpty()){
			return null;
		}
		
		if(numberOfEntries > 0){
			removedPoint = rArray[numberOfEntries-1];
			rArray[numberOfEntries-1] = null;
			numberOfEntries--;
		}
		//shrinks array
		if(numberOfEntries <= rArray.length/3) {
			rArray = Arrays.copyOf(rArray, rArray.length / 2);
		}
		
		return removedPoint;
	}

	@Override
	public void clear() {
		rArray = new Point[DEFAULT_CAPACITY];
		numberOfEntries = 0;
	}

	@Override
	public boolean contains(Point anEntry) {
		for(int i = 0; i < numberOfEntries; i++) {
			if(rArray[i].equals(anEntry)) {
				return true;
			}
		}
		return false;
	}
	
	
	

//unsure how to get union to work
	@Override
	public SetInterface union(SetInterface anotherSet) {
		ResizableArraySet returnArray = new ResizableArraySet();
		
		for(int i = 0; i < numberOfEntries ; i++) {
				returnArray.add(rArray[i]);
		}
		
		for(int i = numberOfEntries; i < anotherSet.getSize() ; i++) {
				returnArray.add(rArray[i]);
		}
		
		return returnArray;
	}
	

	@Override
	public SetInterface intersection(SetInterface anotherSet) {
		ResizableArraySet returnArray = new ResizableArraySet();
		//sees if the point is in both arrays and adds it if so
		for(int i = 0; i < numberOfEntries; i++) {
			if(anotherSet.contains(rArray[i])){
				returnArray.add(rArray[i]);
			}
		}
		return returnArray;
	}
	
	
	

	@Override
	public SetInterface difference(SetInterface anotherSet) {
		ResizableArraySet returnArray = new ResizableArraySet();
		//if the point is not in both arrays it adds it
		for(int i = 0; i < numberOfEntries; i++) {
			if(!anotherSet.contains(rArray[i])) {
				returnArray.add(rArray[i]);
			}
		}
		return returnArray;
	}
	
	

	@Override
	public Point[] toArray() {
		Point[] result = (Point[]) new Object[numberOfEntries];
		for (int i = 0; i < numberOfEntries; i++) {
			result[i] = rArray[i];
		}
		return result;
	}
	
	public void printArray() {
		for(int i = 0; i < rArray.length; i++) {
			System.out.print(rArray[i] + " ");
		}
	}

}
