<?php
$uri = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];

$paths = explode('/', $uri);

session_start();

if(!isset($_SESSION['cart'])){
    $_SESSION['cart']=[];
}

if ($paths[3] === 'cart') {
    $id = $paths[4];
    if($id!==""){
        switch ($method) {
            case 'POST':
                update_quantity($id);
                break;
            case 'DELETE':
                delete_pizza($id);
                break;
            default:
                header('HTTP/1.1 405 Method Not Allowed');
                header('Allow: GET, PUT, POST, DELETE');
        }
    }else{
        switch ($method) {
            case 'POST':
                create_pizza();
                break;
            case 'DELETE':
                delete_cart();
                break;
            case 'GET':
                read_cart();
                break;
            default:
                header('HTTP/1.1 405 Method Not Allowed');
                header('Allow: GET, PUT, POST, DELETE');
        }
        //read create and delete cart
    }
}

function create_pizza(){
    $data = json_decode(file_get_contents('php://input'),true);
    $_SESSION['cart'][]=$data;
    end($_SESSION['cart']);
    $key=key($_SESSION['cart']);
    $_SESSION['cart'][$key]['id']=$key;
    header('Content-type: application/json');
    echo json_encode($_SESSION['cart'][$key]);
}

function read_cart(){
    echo json_encode($_SESSION['cart']);
    header('Content-type: application/json');
}

function delete_cart(){
    $_SESSION['cart']=[];
    header('Content-type: application/json');
    echo json_encode($_SESSION['cart']);
}

function update_quantity($id){
    $data = json_decode(file_get_contents('php://input'),true);
    $_SESSION['cart'][$id]["quantity"]=$data["quantity"];
    header('Content-type: application/json');
    echo json_encode($_SESSION['cart'][$id]);
}
function delete_pizza($id)
{
    if (isset(($_SESSION)['cart'][$id])) {
        unset($_SESSION['cart'][$id]);
        header('HTTP/1.1 204 Method no content');
    } else {
        header('HTTP/1.1 404 not found');
    }
}
