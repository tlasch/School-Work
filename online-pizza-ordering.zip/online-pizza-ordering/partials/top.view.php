<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Rocko Login</title>
    <meta charset="utf-8">
</head>
<body>
<div>
    <a href="index.html">Home</a> | <a href="menu.html">Menu</a> | <a href="order.php">Order</a>
</div>
<h1>Rocco Pizza Party!</h1>
<h2>Come party with some Pizza</h2>
</div>