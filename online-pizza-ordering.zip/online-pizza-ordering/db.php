<?php
$username = 'laschtm';
$password = 'sincere32';
$dbname = 'laschtm';