<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form Submission</title>
    <meta charset="utf-8">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <table class="table table-striped table-bordered">
            <?php
                foreach ($_POST as $key => $value) {
                    echo "<tr>";
                    echo "<td>";
                    echo htmlspecialchars($key);
                    echo "</td>";
                    echo "<td>";
                if (is_array($value))
                    echo htmlspecialchars(join($value, ", "));
                else
                    echo htmlspecialchars($value);
                    echo "</td>";
                    echo "</tr>";
                }
            ?>
        </table>
    </div>
</body>
</html>
