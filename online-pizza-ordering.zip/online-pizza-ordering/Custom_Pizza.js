var count = 1;
$(document).ready(function () {
    $('#TopButton').click(function(){
        $(".CPizza").slideToggle();
    });
    $('#BottomButton').click(function(){
        var size = $('#Pizza_Size').val()
        var crust = $('#Crust_Type').val()
        var Psauce = $('#Pizza_Sauce').val()
        var Pepperoni = $('#Peperoni').val()
        var Sausage = $('#Sausage').val()
        var American = $('#American').val()
        var Peppers = $('#Peppers').val()
        var Mushrooms = $('#Mushrooms').val()
        var toppings = " ";
        if ($('#Pepperoni').prop('Pepperoni')) {
            toppings+=Pepperoni+" ";
        }
        if ($('#Sausage').prop('Sausage')) {
            toppings+=Sausage+" ";
        }
        if ($('#American').prop('American')) {
            toppings+=American+" ";
        }
        if ($('#Peppers').prop('Peppers')) {
            toppings+=Peppers+" ";
        }
        if ($('#Mushrooms').prop('Mushrooms')) {
            toppings+=Mushrooms+" ";
        }

        var newPizza = $('<div>' + 'Pizza: '+ count + ' ' + size + ', ' + crust + ', ' + Psauce + ', ' + ' Toppings: ' + toppings + '<button type="button" class="Remove" data-pizza="pizza'+count+'">Remove Pizza</button> </div>');

        $('.NewCustomOrder').append(newPizza);
        $('.Remove').click(function(){
            $(this).closest("div").remove();
            $("input[name="+$(this).data("pizza")+"]").remove();

        });
        var newInput = $('<input type="hidden" name="pizza' + count + '" value="'+ size + ', ' + crust + ', ' + Psauce + ', ' + toppings+'">');
        $('#Orderform').append(newInput);
        count++;
    })
});


