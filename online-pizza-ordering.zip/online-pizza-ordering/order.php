<?php
session_start();
if ($_SESSION['auth'] !== true) {
    header('Location: http://' . $_SERVER['HTTP_HOST'] . '/online-pizza-ordering/login.php');
}
require 'db.php';
require 'functions.php';

try {
    $pdo = new PDO("mysql:host=localhost;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br />";
    die();
}
?>
<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Rocko Order</title>
    <meta charset="utf-8">
</head>
<body class="orderBody">
<h1 class="titlePage"><img src="home_pizza_slider_1.png" alt="Pizza pie" title="Menu Pizza Image" height="50" width="100"> Rocko Pizza Party</h1>
<div class="above">
    <a href="index.html">Homepage</a><br>
    <a href="menu.html">Menu</a><br>
    <form action="submit.php" id="Orderform" method="post">
        <label class="txt">First Name: <input type="text"
                                              name="fname" /></label><br>
        <label class="txt">Last Name: <input type="text"
                                             name="lname" /></label><br>
</div>
<div class="dinnerOrder">
    <h1 class="funFont dinner">Dinner Order</h1>
    <button type="button" id='TopButton'>Build Your Own</button><br>
    <div  class="CPizza">
        <h3>Custom Pizza</h3>
        <label>Size<select id="Pizza_Size">
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
        </select></label>
        <label>Crust<select id="Crust_Type">
            <option value="Thin Crust">Thin</option>
            <option value="Deep Dish">Deep Dish</option>
            <option value="Pan">Pan</option>
        </select></label>
        <label>Sauce<select id="Pizza_Sauce">
            <option value="BBQ">BBQ</option>
            <option value="Tomato">Tomato</option>
        </select></label><br>

        <?php
        foreach (getIngredients("Topping") as $Topping){
        echo '<input type="checkbox" name="ingredients" value="'.$Topping['Name'].'">'.$Topping['Name'].'<br>';
        }
        ?>

<!---->
<!--        <input type="checkbox" name="ingredient" value="Pepperoni" id="Peperoni"> Peperoni-->
<!--        <input type="checkbox" name="ingredient" value="Sausage" id="Sausage"> Sausage-->
<!--        <input type="checkbox" name="ingredient" value="American" id="American"> American-->
<!--        <input type="checkbox" name="ingredient" value="Peppers" id="Peppers"> Peppers-->
<!--        <input type="checkbox" name="ingredient" value="Mushrooms" id="Mushrooms"> Mushrooms-->
        <button type="button" id='BottomButton'>Submit Custom Pizza</button>
    </div>
    <br>
    <?php
    foreach (getProducts("Pizza") as $Pizza){
       echo '<label class="txt">Number of '.$Pizza['menuItem'].' Pizzas: <input type="text"
                                                              name="qty_'.$Pizza['id'].'" /></label><br>';
    }
    ?>

    <?php
    foreach (getProducts("Subs") as $Subs){
        echo '<label class="txt">Number of '.$Subs['menuItem'].' Subs: <input type="text"
                                                              name="qty_'.$Subs['id'].'" /></label><br>';
    }
    ?>

    <?php
    foreach (getProducts("Salads") as $Salads){
        echo '<label class="txt">Number of '.$Salads['menuItem'].' Salads: <input type="text"
                                                              name="qty_'.$Salads['id'].'" /></label><br>';
    }
    ?>


</div>

<div class="appOrder">
    <h1 class="funFont app">App Order</h1><br>
    <label class="txt">Number of Bread Sticks: <input type="text"
                                                      name="qty_BS" /></label><br>

    <label class="txt">Number of Drinks: <input type="text"
                                                name="qty_D" /></label><br>
</div>
<div class="specialInstructions">
    <br><label class="txt">Special Instructions:</label>
    <textarea name="Special Instructions" cols="10"
              rows="3" placeholder="Special Instructions here"></textarea>
    <input type="submit">
    </form>

    <div style="float:bottom" class="NewCustomOrder">

    </div>
</div>

<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
<script src="Custom_Pizza.js"></script>
</body>
</html>
