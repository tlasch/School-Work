

public class LinkedList {
	
	Node head;
	
	public LinkedList() {
		head = null;
		
	}

	public int countNodes() {
		Node current = head;
		int numberOfEntries = 0;
		while(current!=null) {
			numberOfEntries++;
			current = current.next;
		}
		return numberOfEntries;
	}

	
	public void addToHead(int value) {
		Node newNode = new Node (value);
		if(head==null) {
			head = newNode;
			newNode.next = null;
			return;
		}
		
		newNode.next = head;
		head = newNode;
	}
	
	public String toString() {
		Node current = head;
		String returnString = "[ ";
		while(current!=null) {
			returnString += current.data + " ";
			current = current.next;
		}
		returnString += "]";
		return returnString;
	}

	
	public boolean contains(int value) {
		Node current = head;
		if(head==null) {
			return false;
		}
		
		while(current!=null) {
			if(current.data!=value) {
				current = current.next;
			} else {
				return true;
			}
		}
		
		return false;
	}


	public void addToTail(int value) {
		Node newNode = new Node (value);
		Node current = head;
		if(head==null) {
			head = newNode;
			newNode.next = null;
		}
		
		while(current!=null) {
			if(current != null && current.next == null) {
				current.next = newNode;
				newNode.next = null;
			}
			current = current.next;
		}
	}

	public Node removeFirst() {
		
		Node temp = null;
		if(head!=null) {
			temp = head;
			head = head.next;
		}
		return temp;
	}

	public Node removeLast() {
		Node current = head;
		if(head==null) {
			return head;
		}
		
		if(head.next==null) {
			Node temp = head;
			head = null;
			return temp;
		}
		
		while(current!=null) {
			if(current != null && current.next.next == null) {
				Node temp = current.next;
				current.next = null;
				return temp;
			}
			current = current.next;
		}
		return null;
	}

	public Node lastNode() {
		Node current = head;
		if(head==null) {
			return head;
		}
		
		while(current!=null) {
			if(current != null && current.next == null) {
				return current;
			}
			current = current.next;
		}
		return null;
	}

	public void randomNodes(int n) {
		if(n<0) {
			System.out.println("Use number greater than 0");
		} else {
		for(int i=0; i<n; i++) {
			int data = (int) (Math.random() * 101);
			addToTail(data);
		}
		}
		
	}
	
	

	
	
	
}
