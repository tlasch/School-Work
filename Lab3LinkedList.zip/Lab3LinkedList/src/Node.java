
public class Node {
	int data;
	Node next; //reference to next node
	
	
	public Node() {
		next = null;
	}
	
	public Node(int data) {
		this.data = data;
		next = null;
	}
	
	
	
	
}
