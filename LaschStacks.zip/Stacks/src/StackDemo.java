
public class StackDemo {
	public static void main(String[] args) {
		ArrayStack<Integer> tester1 = new ArrayStack<Integer>();
		LinkedStack<Integer> tester2 = new LinkedStack<Integer>();
		
		tester1.push(1);
		tester1.push(55);
		tester1.push(40);
		
		System.out.println(tester1.peek());
		System.out.println(tester1.peek());
		
		displayStack(tester1);
		//tested clear
		//tester1.clear();
		
		
		System.out.println(tester1.pop());
		System.out.println(tester1.pop());
//		System.out.println(tester1.pop());
		//tests pop if array empty
		//System.out.println(tester1.pop());
		
		tester2.push(2);
		tester2.push(50);
		tester2.push(45);
		
		System.out.println(tester2.peek());
		System.out.println(tester2.peek());
		
		System.out.println(tester2.pop());
		System.out.println(tester2.pop());
		System.out.println(tester2.pop());
		
		//tested clear
//		tester2.clear();
//		System.out.println(tester2.pop());
		
//		System.out.println(tester2.pop());
		
		
	
	}
	
	public static <T> void displayStack(StackInterface<T> stk) {
		ArrayStack<T> tempList = new ArrayStack<T>();
		
		while(!stk.isEmpty()) {
			tempList.push(stk.pop());
		}
		
		while(!tempList.isEmpty()) {
			System.out.println(tempList.peek());
			stk.push(tempList.pop());
		}
	}
}
