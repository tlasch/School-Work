
public class Tester {

	public static void main(String[] args) {
		CircularDeque<String> deque1 = new CircularDeque<>();

		System.out.println("--------Testing add to front--------");
		testAddToFront(deque1);
		System.out.println();
		System.out.println("--------Testing add to back--------");
		testAddToBack(deque1);
		System.out.println();
		System.out.println("--------Testing remove front--------");
		testRemoveFront(deque1);
		System.out.println();
		System.out.println("--------Testing remove back--------");
		testRemoveBack(deque1);
		System.out.println();
		System.out.println("--------Testing get front--------");
		testGetFront(deque1);
		System.out.println();
		System.out.println("--------Testing get back--------");
		testGetBack(deque1);
		System.out.println();
		System.out.println("--------Testing exceptions--------");
		testExceptions(deque1);
		
	}
	
	
	public static <T> void testAddToFront(DequeInterface<T> d) {
		CircularDeque<String> deque1 = new CircularDeque<>();
		deque1.addToFront("1");
		System.out.println("adding 1 to front of empty deque expected value:1  Result:" +deque1.toString());
		deque1.addToFront("4");
		System.out.println("adding 4 to front of deque of 1 expected value:4 1  Result:" +deque1.toString());
		deque1.addToFront("5");
		System.out.println("adding 5 to front of deque of 2 expected value:5 4 1  Result:" +deque1.toString());
		deque1.addToFront("0");
		System.out.println("adding 0 to front of deque of 3 expected value:0 5 4 1  Result:" +deque1.toString());
		
	}
	
	
	public static <T> void testAddToBack(DequeInterface<T> d) {
		CircularDeque<String> deque1 = new CircularDeque<>();
		deque1.addToBack("9");
		System.out.println("adding 9 to back of empty deque expected value:9  Result:" +deque1.toString());
		deque1.addToBack("12");
		System.out.println("adding 12 to back of deque size of 1 expected value:9 12  Result:" +deque1.toString());
		deque1.addToBack("4");
		System.out.println("adding 4 to back of deque size of 2 expected value:9 12 4 Result:" +deque1.toString());
	}
	
	//ask if ok to change the name
	public static <T> void testRemoveFront(DequeInterface<T> d) {
		CircularDeque<String> deque1 = new CircularDeque<>();
		
		
		deque1.addToFront("1");
		deque1.removeFront();
		System.out.println("removing from front of 1 value deque expected value:EMPTY Result:" +deque1.toString());
		deque1.addToFront("1");
		deque1.addToFront("4");
		deque1.addToFront("5");
		deque1.addToFront("0");
		
		deque1.removeFront();
		System.out.println("removing from front of 4 value deque expected value:5 4 1 Result:" +deque1.toString());
	}
	
	public static <T> void testRemoveBack(DequeInterface<T> d) {
		CircularDeque<String> deque1 = new CircularDeque<>();
		
		deque1.addToFront("1");
		deque1.removeBack();
		System.out.println("removing from front of 1 value deque expected value:EMPTY Result:" +deque1.toString());
		
		deque1.addToFront("1");
		deque1.addToFront("4");
		deque1.addToFront("5");
		deque1.addToFront("0");
		deque1.removeBack();
		System.out.println("removing from front of 4 value deque expected value:0 5 4 Result:" +deque1.toString());
		
	}
	
	
	public static <T> void testGetFront(DequeInterface<T> d) {
		CircularDeque<String> deque1 = new CircularDeque<>();
		deque1.addToFront("1");
		deque1.addToFront("4");
		System.out.println("removing from front of empty deque expected value:4 Result:" +deque1.getFront());
		deque1.removeFront();
		System.out.println("removing from front of empty deque expected value:1 Result:" +deque1.getFront());
		
	}
	
	public static <T> void testGetBack(DequeInterface<T> d) {
		CircularDeque<String> deque1 = new CircularDeque<>();
		deque1.addToFront("1");
		deque1.addToFront("4");
		System.out.println("removing from front of empty deque expected value:1 Result:" +deque1.getBack());
		deque1.removeBack();
		System.out.println("removing from front of empty deque expected value:4 Result:" +deque1.getFront());
		
	}
	
	
	public static <T> void testExceptions(DequeInterface<T> d) {
		CircularDeque<String> deque1 = new CircularDeque<>();
		//tests exception handling for remove front from empty dequeue
		try {
			deque1.removeFront();
			System.out.println("removing from front of empty deque expected value: Result:" +deque1.toString());
		} catch(EmptyQueueException e) {
			System.out.println("You tried to removeFront from an empty deque!!");
		} catch (Exception e){
			System.out.println("Threw exception other than empty deque exception");
		}
		
		try {
			deque1.removeBack();
			System.out.println("removing from the back of empty deque expected value: Result:" +deque1.toString());
		} catch(EmptyQueueException e) {
			System.out.println("You tried to removeBack from an empty deque!!");
		} catch (Exception e){
			System.out.println("Threw exception other than empty deque exception");
		}
		
		try {
			System.out.println("removing from front of empty deque expected value: Result:" +deque1.getFront());
		} catch( EmptyQueueException e) {
			System.out.println("No front of empty deque!!");
		} catch (Exception e){
			System.out.println("Threw exception other than empty deque exception");
		}
		
		try {
			System.out.println("removing from front of empty deque expected value: Result:" +deque1.getBack());
		} catch(EmptyQueueException e) {
			System.out.println("No back of empty deque!!");
		} catch (Exception e){
			System.out.println("Threw exception other than empty deque exception");
		}
		
		
	}
	

}
