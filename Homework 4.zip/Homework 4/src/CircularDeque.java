
public class CircularDeque<T> implements DequeInterface<T> {
	DLNode firstNode = null;
	
	private class DLNode <T>{
		private T data; // Deque entry
		private DLNode next; // Link to next node
		private DLNode previous; // Link to previous node
		
		
		private DLNode(T dataPortion) {
			data = dataPortion;
			next = null;
			previous = null;
		} // end constructor

		private DLNode(DLNode previousNode, T dataPortion, DLNode nextNode) {
			data = dataPortion;
			next = nextNode;
			previous = previousNode;
		}
		

	}

	
	@Override
	public void addToFront(T newEntry) {
		DLNode newNode = new DLNode(newEntry);
		DLNode currNode = firstNode;
		if(isEmpty()) {
			firstNode = newNode;
			firstNode.next = newNode;
			firstNode.previous = newNode;
		}
		DLNode back = firstNode.previous;

		newNode.previous = back;
		newNode.next = firstNode;
		back.next = newNode;
		firstNode.previous = newNode;
		firstNode = newNode;
		
		
	}
	
	
	public String toString() {
		String answ = "";
		
		if(isEmpty()) {
			answ = "EMPTY";
			return answ;
		}
		
		DLNode currNode = firstNode;
		
		if(firstNode.next == firstNode) {
			answ += firstNode.data + " ";
		} else {
			answ += currNode.data + " ";
			currNode = currNode.next;
			while(currNode != firstNode) {
				answ += currNode.data + " ";
				currNode = currNode.next;
			}
		}
		return answ;
	}

	@Override
	public void addToBack(T newEntry) {
		DLNode newNode = new DLNode(newEntry);
		DLNode currNode = firstNode;
		if(isEmpty()) {
			firstNode = newNode;
			firstNode.next = newNode;
			firstNode.previous = newNode;
		}
		DLNode back = firstNode.previous;

		newNode.previous = back;
		newNode.next = firstNode;
		back.next = newNode;
		firstNode.previous = newNode;
	}

	@Override
	public T removeFront() {
		if(isEmpty()) {
			throw new EmptyQueueException();
		} else {
			DLNode back = firstNode.previous;
			if(firstNode.next == firstNode) {
				firstNode = null;
				return (T) firstNode;
			} else {
	
				DLNode temp = firstNode.next;
				back.next = temp;
				temp.previous = back;
				firstNode = temp;
			}
		}
		
		return (T) firstNode.data;
	}


	@Override
	public T removeBack() {
		if(isEmpty()) {
			throw new EmptyQueueException();
		}
		DLNode back = firstNode.previous;
		if(firstNode.next == firstNode) {
			firstNode = null;
		} else {
	
		DLNode temp = back.previous;
		temp.next = firstNode;
		firstNode.previous = temp;
		back = temp;
		}
		
		return (T) back.data;
	}

	@Override
	public T getFront() {
		if(isEmpty()) {
			throw new EmptyQueueException();
		}
		return (T) firstNode.data;
	}

	@Override
	public T getBack() {
		if(isEmpty()) {
			throw new EmptyQueueException();
		}
		return (T) firstNode.previous.data;
	}

	@Override
	public boolean isEmpty() {
		return firstNode == null;
	}

	@Override
	public void clear() {
		firstNode = null;
	}
	

}
