public interfaceIMoveable {
	public void move();
	public void stop();
	public int speedUp();
	public int slowDown();
}
