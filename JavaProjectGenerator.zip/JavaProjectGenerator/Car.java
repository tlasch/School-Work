public abstract class Car extends Rectangle implements IMoveable, IDrawable {
	private String make;
	private String model;
	private int year;

 	 public Car clone() {
	 	 return new Car(this);
	 } 


 	 public Car() {
	 	 return this("", "", 0);
	 } 

 	 public Car("", "", 0,){
	 	 setMake(make);
	 	 setModel(model);
	 	 setYear(year);
	 } 


 	 public Car(Car c) {
		this(c.make,c.model,c.year,)
	 } 


 	public String getMake() {
	 	 return make;
	 } 


 	public String getModel() {
	 	 return model;
	 } 


 	private void setYear(int year) {
	 	 this.year=year;
	 } 


 	public int getYear() {
	 	 return year;
	 } 

}
