public interfaceIDrawable {
	public void draw(Graphics g);
}
