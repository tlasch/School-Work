import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class JavaClass {

	//variables
	public String name, extendsFrom, implementsInterfaces;
	public boolean abstractClass, cloneMethod, emptyConstructor;
	public boolean workhorseConstructor, copyConstructor;
	
	public ArrayList<JavaProperty> properties = new ArrayList<JavaProperty>();
	
	//scanning in data
	public JavaClass(Scanner fin) {
		name = Utilities.nextLineData(fin);
		abstractClass = Utilities.nextLineBoolean(fin);
		extendsFrom = Utilities.nextLineData(fin);
		implementsInterfaces = Utilities.nextLineData(fin);
		cloneMethod = Utilities.nextLineBoolean(fin);
		emptyConstructor = Utilities.nextLineBoolean(fin);
		workhorseConstructor = Utilities.nextLineBoolean(fin);
		copyConstructor = Utilities.nextLineBoolean(fin);
		
		
		while(true) {
			String s = fin.nextLine().replace("\t", "");
			if(s.equalsIgnoreCase("End Class:")) break;
			if(s.equalsIgnoreCase("Property:")) 
				properties.add(new JavaProperty(fin));
			
		}
	}
	//methods
	
	public void save() {
		PrintWriter pw = null;
		
		try {
			String mainString="";
			//top of class
			pw = new PrintWriter(new File(name + ".java"));
			
			pw.println("public" + (abstractClass ? " abstract" : "") +
					" class " + name +
					(extendsFrom.length() > 0 ? " extends " + extendsFrom : "") +
					(implementsInterfaces.length() > 0 ? " implements " + implementsInterfaces : "") +
					" {");
			
			//saves properties
			for(JavaProperty jp : properties) {
				jp.save(pw);
			}
			
			
			///workhorse
			for(JavaProperty jp : properties) {
				mainString+= jp.type + " " + jp.name +",";
			}
			
			

			//creates clone method
			if(cloneMethod) {
			pw.println("\n \t public " + name + " clone() {");
			pw.println("\t \t return new " + name + "(this);");
			pw.println(("\t } \n"));
			}
			

			
			//creates empty constructor
			if(emptyConstructor) {
			pw.println("\n \t public " + name + "() {");
			pw.print("\t \t return " + "this(");	
			mainString = "";
			//sets all to null
			for(JavaProperty jp : properties) {
				if(jp.type.equalsIgnoreCase("String")) {
					mainString+="\"\"" + ", ";
				}
					
				if(jp.type.equals("int")) {
					mainString+="0" + ", ";
				}
					
				if(jp.type.equals("boolean")) {
					mainString+="false" + ", ";
				}	
			}
			pw.print(mainString.substring(0,mainString.length()-2));
			pw.print(");\n\t } \n");
			}
			
			//creates workhorse constructor
			if(workhorseConstructor) {
			pw.println("\n \t public " + name + "(" + mainString.substring(0,mainString.length()-1) + "){");
			for(JavaProperty jp : properties) {
				pw.println("\t \t set"+Utilities.camelCase(jp.name) +"("+jp.name + ");");
			}
			pw.println("\t } \n");
			}
			
			mainString = "";
			
			//creates copy constructor
			if(copyConstructor) {
			pw.println("\n \t public " + name + "("+ name + " c) {");
			for(JavaProperty jp : properties) {
				mainString+=name.substring(0,1).toLowerCase()+ "." + jp.name +",";
			}
			pw.println("\t\tthis("+mainString + ")");
			
			pw.println("\t } \n");
			}
		
			
			for(JavaProperty jp : properties) {
				jp.saveGettersSetters(pw);
			}
			
			pw.println("}");
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(pw != null) pw.close();
		}
	}

}
