import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

//Timmy Lasch project 1
public class App {

	private static ArrayList<JavaClass> classes = new ArrayList<JavaClass>();
	private static ArrayList<JavaInterface> interfaces = new ArrayList<JavaInterface>();
	
	
	
	public static void main(String[] args) {
		Scanner fin = null;
		
		try {
			fin = new Scanner(new File("javaScript.txt"));
			while(fin.hasNextLine()) {
				String s = fin.nextLine();
				if(s.equalsIgnoreCase("Class:"))
					classes.add(new JavaClass(fin));
				else if(s.equalsIgnoreCase("Interface:"))
					interfaces.add(new JavaInterface(fin));
			}
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(fin != null) fin.close();
		}
		
		for(JavaClass jc : classes)
			jc.save();
		
		
		for(JavaInterface ji : interfaces)
			ji.save();

	}

}
