import java.io.PrintWriter;
import java.util.Scanner;

public class JavaProperty {

	//variables
	public String name, type, scope, getterScope, setterScope;
	public boolean getter, setter;
	
	
	public JavaProperty(Scanner fin) {
		//reading variables
		name = Utilities.nextLineData(fin);
		type = Utilities.nextLineData(fin);
		scope = Utilities.nextLineData(fin);
		getter = Utilities.nextLineBoolean(fin);
		getterScope = Utilities.nextLineData(fin);
		setter = Utilities.nextLineBoolean(fin);
		setterScope = Utilities.nextLineData(fin);
	}
		

		
		//adding variables to class
		public void save(PrintWriter pw) {
			pw.println("\t" + scope + " "+ type + " " + name +";");
	    }
		
		//generates getters and setters
		public void saveGettersSetters(PrintWriter pw) {
			
			if(setter) {
			pw.println("\n \t" + setterScope + " void set" + Utilities.camelCase(name) + "(" + type + " " + name + ") {");
			pw.println("\t \t this." + name + "=" + name + ";");
			pw.println("\t } \n");
			}
			
			if(getter) {
			pw.println("\n \t" + getterScope + " " + type + " get" + Utilities.camelCase(name) + "() {");
			pw.println("\t \t return " + name + ";");
			pw.println("\t } \n");
			}
		}


}
