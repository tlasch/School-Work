

public class NoDuplicatesQueueArray<T> implements NoDuplicatesQueueInterface<T> {

	private T[] arrayQueue; //creating array
	private int frontIndex; // Index of front entry
	private int backIndex; // Index of back entry
	private static final int DEFAULT_CAPACITY = 10;
	private static final int MAX_CAPACITY = 10000;
	
	public NoDuplicatesQueueArray() {
		
		this(DEFAULT_CAPACITY);
	}
	
	public NoDuplicatesQueueArray(int initialCapacity) {
		
		@SuppressWarnings("unchecked")
		T[] tempQueue = (T[]) new Object[initialCapacity + 1];
		arrayQueue = tempQueue;
		frontIndex = 0;
		backIndex = initialCapacity;
	}



	@Override
	public void enqueue(T newEntry) {
		boolean contains = false;
		
		for(int i = 0; i < arrayQueue.length; i++) {
			if(arrayQueue[i] == newEntry) {
				
				contains = true;
			}
		}
		
		if(contains == false) {
			
		ensureCapacity(); //make sure there is room to add
		backIndex = (backIndex + 1) % arrayQueue.length;
		arrayQueue[backIndex] = newEntry;
		} else {
			
			System.out.println("Queue contains Entry");
		}
	}

	@Override
	public T dequeue() {
		if(isEmpty()) {
			
			throw new EmptyQueueException();
		} else {
			
			T frontEntry = arrayQueue[frontIndex];
			arrayQueue[frontIndex] = null;
			frontIndex = (frontIndex + 1) % arrayQueue.length; // Index of new front of queue
			return frontEntry;
		}
	}

	@Override
	public T getFront() {
		if(isEmpty()) {
			
			throw new EmptyQueueException();
		} else {
			
			return arrayQueue[frontIndex];
		}
	}

	@Override
	public boolean isEmpty() {
		return frontIndex == ((backIndex + 1) % arrayQueue.length);
	}

	@Override
	public void clear() {
		//makes sure not clearing empty array
		if(!isEmpty()) {
			for (int index = frontIndex; index != backIndex; index = (index + 1) % arrayQueue.length) {
				
				arrayQueue[index] = null;
			}

			arrayQueue[backIndex] = null;
		}

		frontIndex = 0;
		backIndex = arrayQueue.length - 1;
	}
	
	
	@Override
	public void moveToBack(T newEntry) {
		boolean contains = false;
		int location = frontIndex;
		
		for(int i = 0; i < arrayQueue.length; i++) {
			if(arrayQueue[i] == newEntry) {
				
				contains = true;
				location = i;
			}
		}
		
		if(contains==false) {
			
			enqueue(newEntry);
		} else {
			
			ensureCapacity(); //make sure there is room to add
			for(int i = location; i < backIndex; i++) {
				
				arrayQueue[i] = arrayQueue[i + 1];
				i = i % arrayQueue.length;
			}
			
			arrayQueue[backIndex] = newEntry;
		}
		
	}
	
	private void checkCapacity(int capacity) {
		if(capacity > MAX_CAPACITY) {
			
			throw new IllegalStateException("Attempt to create a queue which capacity exceeds allowed max");
		}
	}
	
	
	private void ensureCapacity() {
		// If array is full double size of array
		if(frontIndex == ((backIndex + 2) % arrayQueue.length)) { 
			
			T[] ogQueue = arrayQueue;
			int oldSize = ogQueue.length;
			int newSize = 2 * oldSize;
			checkCapacity(newSize - 1); // Queue capacity is 1 fewer than array

			// The cast is safe because the new array contains null entries
			@SuppressWarnings("unchecked")
			T[] tempQueue = (T[]) new Object[newSize];
			arrayQueue = tempQueue;

			// Number of queue entries = oldSize - 1; index of last entry = oldSize - 2
			for(int index = 0; index < oldSize - 1; index++) {
				arrayQueue[index] = ogQueue[frontIndex];
				frontIndex = (frontIndex + 1) % oldSize;
			}

			frontIndex = 0;
			backIndex = oldSize - 2;
		}
	}

	@Override
	public String toString() {
		String returnString = "";
		//have to include <= because index at 0
		for(int i = 0; i <= backIndex; i++) {
			returnString = returnString + arrayQueue[i]+ " ";
		}
		
		return returnString;
	}
	
	//used to make sure resizing of array works
	public int getSize() {
		return arrayQueue.length;
	}
	

}
