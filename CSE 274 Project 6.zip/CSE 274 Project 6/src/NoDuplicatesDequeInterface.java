
public interface NoDuplicatesDequeInterface<T> extends DequeInterface<T> {
	public void moveToBack(T newEntry);
	public void moveToFront(T newEntry);
}
