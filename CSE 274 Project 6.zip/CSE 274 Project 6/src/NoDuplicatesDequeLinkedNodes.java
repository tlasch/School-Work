
public class NoDuplicatesDequeLinkedNodes<T> implements NoDuplicatesDequeInterface<T> {

	private DLNode firstNode;
	private DLNode lastNode; 
	
	//DLNode class
	private class DLNode {
		
		private T      data;  	 // Deque entry data
		private DLNode next;  	 // Link to next node
		private DLNode previous; // Link to previous node

		private DLNode(T data) {
			
			this.data = data;
			next = null;	
			previous = null;	
		}
		
		private DLNode(DLNode previousNode, T data, DLNode nextNode) {
			
			this.data = data;
			next = nextNode;	
			previous = previousNode;
		}
		
	}
	
	public NoDuplicatesDequeLinkedNodes() {
		firstNode = null;
		lastNode = null;
	}
	
	public boolean contains(T anEntry) {
		DLNode traverseNode = firstNode;
		
		while(traverseNode != null) {
			if(traverseNode.data.equals(anEntry)) {
				
				return true;
			}
			
			traverseNode = traverseNode.next;
		}
		
		return false;
	}
	
	
	@Override
	public void addToFront(T newEntry) {
		DLNode newNode = new DLNode(null, newEntry, firstNode);

		if(!contains(newEntry)) {
		
		if (isEmpty()) {
			
			lastNode = newNode;
			firstNode = newNode;
			
		} else {
			
			firstNode.previous= newNode;
			firstNode = newNode;
		}
		
		} else {
			//prints message if the entry is already contained
			System.out.println("DeQueue contains Entry");
		}
	}

	@Override
	public void addToBack(T newEntry) {
		DLNode newNode = new DLNode(newEntry);
		
		if(!contains(newEntry)) {
		
		if(isEmpty()) {
			
			lastNode = newNode;
			firstNode = newNode;
			newNode.next = null;
			
		} else {
			
			lastNode.next = newNode;
			newNode.next = null;
			newNode.previous = lastNode;
			lastNode = newNode;
		}
		
		} else {
			//prints message if the entry is already contained
			System.out.println("DeQueue contains Entry");
		}
		
	}

	@Override
	public T removeFront() {
		T front = getFront();
		assert (firstNode != null);
		firstNode = firstNode.next;

		if (firstNode == null) {
			
			lastNode = null;
		} else {
			
			firstNode.previous = null;
		} 
		
		return front;
	}

	@Override
	public T removeBack() {
		if(isEmpty()) {
			//throw exception
			throw new EmptyQueueException();
		} else if(firstNode == lastNode) {
			
			DLNode tempNode = firstNode;
			firstNode = null;
			lastNode = null;
			return tempNode.data;
		} else {	
			
			DLNode tempNode = lastNode;
			lastNode.previous.next = null;
			lastNode = lastNode.previous;
			return tempNode.data;
		}
	}

	@Override
	public T getFront() {
		if(isEmpty()) {
			//throw exception
			throw new EmptyQueueException();
		} else {
			
			return firstNode.data;
		}
	}

	@Override
	public T getBack() {
		if(isEmpty()) {
			//throw exception
			throw new EmptyQueueException();
		} else {
			
			return lastNode.data;
		}
	}

	@Override
	public boolean isEmpty() {
		return (firstNode == null) && (lastNode == null);
	}

	@Override
	public void clear() {
		firstNode = null;
		lastNode = null;
	}

	@Override
	public void moveToBack(T anEntry) {
		if(contains(anEntry)) {
			DLNode traverseNode = firstNode;
			
			while(traverseNode != null) {
				if(lastNode.data.equals(anEntry)) {
					//does nothing if already at back
					break;
				}
				if(traverseNode.data.equals(anEntry)) {
					
					traverseNode.previous.next = traverseNode.next;
					traverseNode.next.previous = traverseNode.previous;
					addToBack(anEntry);
					//break or else keeps running
					break;
				}
				
				traverseNode = traverseNode.next;
			}
		} else {
			
			addToBack(anEntry);
		}
		
	}

	@Override
	public void moveToFront(T anEntry) {
		if(contains(anEntry)) {
			DLNode traverseNode = firstNode;
			
			while(traverseNode != null) {
				if(firstNode.data.equals(anEntry)) {
					//does nothing if already at front
					break;
				}
				if(traverseNode.data.equals(anEntry)) {
					
					traverseNode.previous.next = traverseNode.next;
					traverseNode.next.previous = traverseNode.previous;
					addToFront(anEntry);
					//break or else keeps running
					break;
				}
				
				traverseNode = traverseNode.next;
			}
		} else {
			
			addToFront(anEntry);
		}
	}

	@Override
	public String toString() {
		
		DLNode traverseNode = firstNode;
		String returnString = "";
		
		while(traverseNode != null) {
			
			returnString = returnString + traverseNode.data + " ";
			traverseNode = traverseNode.next;
		}
		
		return returnString;
	}
	
	

}
