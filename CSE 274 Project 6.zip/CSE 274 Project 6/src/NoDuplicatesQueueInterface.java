
public interface NoDuplicatesQueueInterface<T> extends QueueInterface<T> {

	public void moveToBack(T newEntry);
}
