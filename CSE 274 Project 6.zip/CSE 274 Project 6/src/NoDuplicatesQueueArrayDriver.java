
public class NoDuplicatesQueueArrayDriver {

	public static void main(String[] args) {
		NoDuplicatesQueueArray<String> myQueue = new NoDuplicatesQueueArray<String>(10);
		//queue that is empty
		System.out.println("testing is empty");
		System.out.println(myQueue.isEmpty());
		
		//testing adding to the queue
		System.out.println("testing adding to enqueue");
		myQueue.enqueue("4");
		System.out.println(myQueue.toString());
		
		//testing adding duplicate element...doesnt work and reports error
		System.out.println("testing adding same element to enqueue");
		myQueue.enqueue("4");
		System.out.println(myQueue.toString());
		
		//adding more elements
		System.out.println("testing adding to enqueue");
		myQueue.enqueue("7");
		System.out.println(myQueue.toString());
		
		System.out.println("testing adding to enqueue");
		myQueue.enqueue("8");
		System.out.println(myQueue.toString());
		
		//testing getting the first element
		System.out.println("testing getFront expected: 4");
		System.out.println("value " + myQueue.getFront());
		
		//moving the element to the back not included...should just add to back
		System.out.println("testing move to back on element not included");
		myQueue.moveToBack("1");
		System.out.println(myQueue.toString());
		
		//testing element already at back...should keep queue the same
		System.out.println("testing move to back on element included and located at back");
		myQueue.moveToBack("1");
		System.out.println(myQueue.toString());
		
		//should move to back
		System.out.println("testing move to back on element included");
		myQueue.moveToBack("4");
		System.out.println(myQueue.toString());
		
		//testing dequeue from the queue
		System.out.println("testing dequeue");
		myQueue.dequeue();
		System.out.println(myQueue.toString());
		
		System.out.println("testing dequeue again");
		myQueue.dequeue();
		System.out.println(myQueue.toString());
		
		//testing clear
		System.out.println("testing clear");
		myQueue.clear();
		System.out.println("testing is empty");
		System.out.println(myQueue.isEmpty());
		System.out.println(myQueue.toString());
		
		//testing resizing
		System.out.println("Testing resizing");
		NoDuplicatesQueueArray<Integer> myResizeQueue = new NoDuplicatesQueueArray<Integer>(10);
		//original size of array
		System.out.println("Original size");
		System.out.println(myResizeQueue.getSize());
		for(int i = 0; i < 11; i++) {
			myResizeQueue.enqueue(i);
		}
		
		//doubles the array size should be 22
		System.out.println("Resized size...expected size 22");
		System.out.println(myResizeQueue.getSize());
		
	}

}
