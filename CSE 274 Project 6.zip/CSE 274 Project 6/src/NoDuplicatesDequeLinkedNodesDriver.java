
public class NoDuplicatesDequeLinkedNodesDriver {

	public static void main(String[] args) {
		NoDuplicatesDequeLinkedNodes<String> myDeque = new NoDuplicatesDequeLinkedNodes<>();
		//testing is empty
		System.out.println("testing is empty");
		System.out.println(myDeque.isEmpty());
		
		//testing adding to front
		myDeque.addToFront("4");
		System.out.println(myDeque.toString());
		//checking if add to front works
		myDeque.addToFront("5");
		System.out.println("adding 5 to front");
		System.out.println(myDeque.toString());
		
		//testing duplicate
		System.out.println("testing adding duplicate and making sure doesnt work for addFront");
		myDeque.addToFront("4");
		System.out.println(myDeque.toString());
		
		//adding to back
		myDeque.addToBack("8");
		System.out.println("adding 8 to back");
		System.out.println(myDeque.toString());
		
		//duplicate for adding back
		System.out.println("testing adding duplicate and making sure doesnt work for addBack");
		myDeque.addToBack("4");
		System.out.println(myDeque.toString());
		
		//remove from front
		System.out.println("Testing removing from the front");
		myDeque.removeFront();
		System.out.println(myDeque.toString());
		
		//adding removed value back so that the Deque is full again
		System.out.println("adding removed value back");
		myDeque.addToFront("5");
		System.out.println(myDeque.toString());
		
		//remove from back test
		System.out.println("Testing removing from the back");
		myDeque.removeBack();
		System.out.println(myDeque.toString());
		
		//testing getting first element
		System.out.println("Testing get front: expected 5");
		System.out.println(myDeque.getFront());
		
		//testing getting back element
		System.out.println("Testing get back: expected 4");
		System.out.println(myDeque.getBack());
		
		//moving element to back that is not in deque...should add to back
		System.out.println("testing move to back on element not included");
		myDeque.moveToBack("7");
		System.out.println(myDeque.toString());
		
		//testing element already in last spot...nothing should happen
		System.out.println("testing move to back on element included in last spot");
		myDeque.moveToBack("7");
		System.out.println(myDeque.toString());
		
		//testing moving to back...4 should be last now
		System.out.println("testing move to back on element included");
		myDeque.moveToBack("4");
		System.out.println(myDeque.toString());
		
		//moving element to front..should add element to front since not included
		System.out.println("testing move to front on element not included");
		myDeque.moveToFront("8");
		System.out.println(myDeque.toString());
		
		//testing move to front on element already at front...should remain same
		System.out.println("testing move to front on element included in front position");
		myDeque.moveToFront("8");
		System.out.println(myDeque.toString());
		
		//testing move to front
		System.out.println("testing move to front on element included not in front position");
		myDeque.moveToFront("7");
		System.out.println(myDeque.toString());
		
		//clearing the deque
		System.out.println("testing clear");
		myDeque.clear();
		System.out.println(myDeque.toString());
	}

}
