
public class Fruit {
	
	String color, name;
	
	public Fruit(String color,String name) {
		color = getColor();
		name = getName();
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return color + " " + name;
	}
	
	public boolean equals(Fruit a, Fruit b) {
		if(a.color.equals(b.color) && a.name.equals(b.name)) {
			return true;
		}
		return false;
	}

}
