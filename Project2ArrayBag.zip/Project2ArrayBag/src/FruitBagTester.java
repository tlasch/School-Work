import static org.junit.Assert.*;

import org.junit.Test;

public class FruitBagTester {

	
	//tests get current size from empty array and with one and more than one element
	@Test
	public void testGetCurrentSize() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		
		assertEquals(0,fruitBag1.getCurrentSize());
		
		fruitBag1.add("Mike");
		
		assertEquals(1,fruitBag1.getCurrentSize());
		
		fruitBag1.add("Jay");
		
		assertEquals(2,fruitBag1.getCurrentSize());
		
	}
	
	//tests is Empty from empty array and more than one element
	@Test
	public void testIsEmpty() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		
		assertEquals(0,fruitBag1.getCurrentSize());
		
		assertTrue(fruitBag1.isEmpty());
		
		fruitBag1.add("Andrew");
		
		assertFalse(fruitBag1.isEmpty());
		
	}
	
	//tests add to empty array and with one element and more than one element and once full
	@Test
	public void testAdd() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		
		assertEquals(0,fruitBag1.getCurrentSize());
		assertTrue(fruitBag1.isEmpty());
		
		fruitBag1.add("Mike1");
		
		assertTrue(fruitBag1.contains("Mike1"));
		
		fruitBag1.add("Mike2");
		fruitBag1.add("Mike3");
		fruitBag1.add("Mike4");
		fruitBag1.add("Mike5");
		fruitBag1.add("Mike6");
		fruitBag1.add("Mike7");
		fruitBag1.add("Mike8");
		fruitBag1.add("Mike9");
		fruitBag1.add("Mike10");
		fruitBag1.add("Mike11");
		
		
		assertFalse(fruitBag1.contains("Mike11"));
		
	}
	
	
	//tests removing to an empty array and with one element and more than one element
	@Test
	public void testRemove() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		assertEquals(0,fruitBag1.getCurrentSize());
		assertTrue(fruitBag1.isEmpty());
		assertEquals(null,fruitBag1.remove());
		
		fruitBag1.add("Andrew");
		assertTrue(fruitBag1.contains("Andrew"));
		
		assertTrue(fruitBag1.remove().equals("Andrew"));
		
		
		fruitBag1.add("Dave");
		assertTrue(fruitBag1.contains("Dave"));
		fruitBag1.add("Dave 2");
		assertTrue(fruitBag1.contains("Dave 2"));
		assertTrue(fruitBag1.remove().equals("Dave 2"));
		
		assertTrue(fruitBag1.remove().equals("Dave"));
	}
	
	
	//tests removing to an empty array and with one element and more than one element and finally
	//trying to remove an element thats not present
	@Test
	public void testRemoveAnEntry() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		assertEquals(0,fruitBag1.getCurrentSize());
		assertTrue(fruitBag1.isEmpty());
		assertFalse(fruitBag1.contains("Mark"));
		assertFalse(fruitBag1.remove("Mark"));
		
		fruitBag1.add("Andrew");
		assertTrue(fruitBag1.contains("Andrew"));
		assertTrue(fruitBag1.remove("Andrew"));
		
		fruitBag1.add("Kark");
		fruitBag1.add("Hank");
		fruitBag1.add("Zach");
		fruitBag1.add("Paul");
		
		assertTrue(fruitBag1.contains("Kark"));
		assertTrue(fruitBag1.contains("Hank"));
		assertTrue(fruitBag1.contains("Zach"));
		assertTrue(fruitBag1.contains("Paul"));
		assertTrue(fruitBag1.remove("Zach"));
		
	}
	
	
	//tests clearing an empty array and an array with elements in it
	@Test
	public void testClear() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		assertEquals(0,fruitBag1.getCurrentSize());
		assertTrue(fruitBag1.isEmpty());
		fruitBag1.clear();
		assertTrue(fruitBag1.isEmpty());
		
		fruitBag1.add("Steve");
		fruitBag1.add("Terry");
		fruitBag1.add("Tom");
		fruitBag1.add("Kyle");
		
		assertTrue(fruitBag1.contains("Steve"));
		assertTrue(fruitBag1.contains("Terry"));
		assertTrue(fruitBag1.contains("Tom"));
		assertTrue(fruitBag1.contains("Kyle"));
		
		fruitBag1.clear();
		assertTrue(fruitBag1.isEmpty());
	}
	
	
	//Tests the frequency of an element in the array and returns the number of times that element is found
	@Test
	public void testGetFrequencyOf() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		assertEquals(0,fruitBag1.getCurrentSize());
		assertTrue(fruitBag1.isEmpty());
		
		assertEquals(0,fruitBag1.getFrequencyOf("Sam"));
		
		fruitBag1.add("Mark");
		fruitBag1.add("Ben");
		fruitBag1.add("Kobe");
		fruitBag1.add("Carlos");
		assertTrue(fruitBag1.contains("Mark"));
		assertTrue(fruitBag1.contains("Ben"));
		assertTrue(fruitBag1.contains("Kobe"));
		assertTrue(fruitBag1.contains("Carlos"));
		
		assertEquals(1,fruitBag1.getFrequencyOf("Mark"));
		fruitBag1.add("Mark");
		fruitBag1.add("Mark");
		assertEquals(3,fruitBag1.getFrequencyOf("Mark"));
		
	}
	
	
	//tests if the array contains an element and returns if it does or doesnt, tested on empty array and one
	//with elements
	@Test
	public void testContains() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		assertEquals(0,fruitBag1.getCurrentSize());
		assertTrue(fruitBag1.isEmpty());
		
		assertFalse(fruitBag1.contains("Tim"));
		
		fruitBag1.add("John");
		assertTrue(fruitBag1.contains("John"));
		
		fruitBag1.add("Jack");
		assertTrue(fruitBag1.contains("Jack"));
	}
	
	
	//unable to think of proper way to test toArray. Attempted setting a new array = fruitBag1.toArray();
	//but was not able to get it to work
	@Test
	public void testToArray() {
		FruitBag<String> fruitBag1 = new FruitBag<String>(10);
		assertEquals(0,fruitBag1.getCurrentSize());
		assertTrue(fruitBag1.isEmpty());
		
		fruitBag1.add("John");
		fruitBag1.add("Jack");
		
		fruitBag1.toArray();
		
		assertTrue(fruitBag1.contains("John"));
		assertTrue(fruitBag1.contains("Jack"));

		
		
	}
	
	
	
}
