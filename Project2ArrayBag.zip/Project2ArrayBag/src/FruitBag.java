
public class FruitBag<T> implements BagInterface<T> {

	//The array being implemented as a bag
	private final T[] FruitBag;
	//number of entries in the array
	private int numberOfEntries;
	//the default capacity of the array
	private static int DEFAULT_CAPACITY = 10;
	
	
	//constructor to default capacity
	public FruitBag() {
		this(DEFAULT_CAPACITY);
	} 
	
	//constructor to a chosen size
	public FruitBag(int capacity) {
		@SuppressWarnings("unchecked")
		T[] tempBag = (T[]) new Object[capacity];
		FruitBag = tempBag;
		numberOfEntries = 0;
	}


	//returns the number of entries in the array
	@Override
	public int getCurrentSize() {
		return numberOfEntries;
	}

	
	//returns if the array is empty or not
	@Override
	public boolean isEmpty() {
		if (numberOfEntries > 0) { 
			return false; 
		} else {
			return true;
		}
	}

	
	//adds element to the array and returns false if it was added or if array is full
	@Override
	public boolean add(T anEntry) {
		if(numberOfEntries >= FruitBag.length) {
			return false;
		} else { 
			FruitBag[numberOfEntries] = anEntry;
			numberOfEntries++;
			return true;
		}
	}

	
	
	
	//removes any element from the array
	@Override
	public T remove() {
		T removedInt = null;
		
		if(numberOfEntries > 0){
			removedInt = FruitBag[numberOfEntries-1];
			FruitBag[numberOfEntries-1] = null;
			numberOfEntries--;
		}
		
		return removedInt;
	}

	
	//removes a select entry from the array
	@Override
	public boolean remove(T anEntry) {
		if(isEmpty()) {
			return false;
		} else {
			for(int i=0; i< numberOfEntries; i++) {
				if(FruitBag[i].equals(anEntry)){
					FruitBag[i] = FruitBag[numberOfEntries-1];
					FruitBag[numberOfEntries-1] = null;
					numberOfEntries--;
					return true;
				}
			}
		}return false;
	}

	
	
	//clears the array
	@Override
	public void clear() {
		for(int i=0; i< numberOfEntries; i++) {
			FruitBag[i]=null;
		}numberOfEntries=0;
		
	}

	
	//returns the number of occurrences an entry appears in an array
	@Override
	public int getFrequencyOf(T anEntry) {
		int numOccurance = 0;
		for(int i = 0; i < numberOfEntries; i++) {
			if(FruitBag[i].equals(anEntry)){
				numOccurance++;
			}
		}
		return numOccurance;
	}

	
	//tests to see if the array contains an entry
	@Override
	public boolean contains(T anEntry) {
		for(int i=0; i< numberOfEntries; i++) {
			if(FruitBag[i].equals(anEntry)){
				return true;
			}
		}return false;
	}

	
	//prints the entries to the array
	@Override
	public T[] toArray() {
		@SuppressWarnings("unchecked")
		T[] result = (T[]) new Object[numberOfEntries];
		for (int i = 0; i < numberOfEntries; i++) {
			result[i] = FruitBag[i];
		}
		return result;
	}

}
