import java.util.ArrayList;
import java.util.Iterator;

public class GraphAdjList {
	final int MAX_VERTEX = 26;
	Vertex [] vertices;
	ArrayList<ArrayList<Vertex>> adjList;
	int numEdges;
	int numVertices;
	
	public GraphAdjList() {
		vertices = new Vertex[MAX_VERTEX];
		numVertices = 0;
		numEdges = 0;
		adjList = new ArrayList<ArrayList<Vertex>>(MAX_VERTEX);
		for(int i = 0; i < MAX_VERTEX; i++) {
			adjList.add(new ArrayList<Vertex>());
		}

		
	}
	
	public boolean addVertex(Vertex v) {
		if(vertices[v.getIndex()]!=null) {
			return false;
		}
		vertices[v.getIndex()] = v;
		numVertices++;
		return true;
	}
	
	public boolean removeVertex(Vertex v) {
return false;
	
	}
	
	public boolean addEdge(Vertex u, Vertex v) {
		if(vertices[u.getIndex()]==null || vertices[v.getIndex()]==null) {
			return false;
		}
			if(adjList.get(u.getIndex()).contains(v)==false) {
				
			
			adjList.get(u.getIndex()).add(v);
			adjList.get(v.getIndex()).add(u);
			numEdges++;
			return true;
			}
		return false;
	}
	
	public boolean removeEdge(Vertex u, Vertex v) {
		if(vertices[u.getIndex()]==null || vertices[v.getIndex()]==null) {
			return false;
		}
			if(adjList.get(u.getIndex()).contains(v)) {
				
			
			adjList.get(u.getIndex()).remove(v);
			adjList.get(v.getIndex()).remove(u);
			numEdges--;
			return true;
			}
		return false;
	}
	
	public String toString() {
		String str = "";
		
		for(ArrayList<Vertex> list : adjList) {
			if(list.size()>0) {
				str += (char)(adjList.indexOf(list) + 'A');
				for(Vertex vertex: list) {
					str += "->" + vertex.label;
				}
				str += "\n";
			}
		}
			
		return str;
	}
	
	public int getNumberOfVertices() {
		return numVertices;
	}

	public int getNumberOfEdges() {
		return numEdges;
	}
}
