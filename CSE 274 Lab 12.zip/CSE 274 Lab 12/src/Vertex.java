
public class Vertex {
char label;

public Vertex(char label){
	this.label = label;
}

public int getIndex() {
	return (int)Character.toUpperCase(label) - (int)'A';
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Vertex other = (Vertex) obj;
	if (label != other.label)
		return false;
	return true;
}

}
