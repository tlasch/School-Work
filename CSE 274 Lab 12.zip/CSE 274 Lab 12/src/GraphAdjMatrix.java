
public class GraphAdjMatrix {
	
final int MAX_VERTEX = 26;
Vertex [] vertices;
int [] [] adjMatrix;
int numEdges;
int numVertices;

	
	public GraphAdjMatrix() {
		vertices = new Vertex[MAX_VERTEX];
		adjMatrix = new int[MAX_VERTEX] [MAX_VERTEX];
		numVertices = 0;
		numEdges = 0;
		}
	
	public boolean addVertex(Vertex v) {
		if(vertices[v.getIndex()]!=null) {
			return false;
		}
		vertices[v.getIndex()] = v;
		numVertices++;
		return true;
	}
	
	public boolean removeVertex(Vertex v) {
if(vertices[v.getIndex()]==null) {
	return false;
}
for(int i = 0; i < MAX_VERTEX; i++) {
	if(adjMatrix[v.getIndex()][i]==1) {
		adjMatrix[v.getIndex()][i]=0;
		adjMatrix[i][v.getIndex()]=0;
		numEdges--;
	}
}
vertices[v.getIndex()] = null;
numVertices--;
return true;
	}
	
	public boolean addEdge(Vertex u, Vertex v) {
if(vertices[u.getIndex()]==null || vertices[v.getIndex()]==null) {
	return false;
}
if(adjMatrix[u.getIndex()][v.getIndex()] == 0) {
	adjMatrix[u.getIndex()][v.getIndex()] = 1;
	adjMatrix[v.getIndex()][u.getIndex()] = 1;
	numEdges++;
	return true;
}
return false;

	}
	
	public boolean removeEdge(Vertex u, Vertex v) {
		if(vertices[u.getIndex()]==null || vertices[v.getIndex()]==null) {
			return false;
		}
		if(adjMatrix[u.getIndex()][v.getIndex()] == 1) {
			adjMatrix[u.getIndex()][v.getIndex()] = 0;
			adjMatrix[v.getIndex()][u.getIndex()] = 0;
			numEdges--;
			return true;
		}
		return false;
	}
	
	public String toString() {
		String str = "";
		
		for(int i = 0; i < MAX_VERTEX; i++) {
			if(vertices[i] != null) {
				str += vertices[i].label;
				for(int j = 0; j < MAX_VERTEX; j++) {
					if(adjMatrix[i][j] != 0)
						str += "->" + vertices[j].label;
				}
				str += "\n";
			}
		}
			
		return str;
	}
	
	public int getNumberOfVertices() {
		return numVertices;
	}

	public int getNumberOfEdges() {
		return numEdges;
	}
}
