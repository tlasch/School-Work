//Parts working: All methods except for add(int), for JUnit testing all methods except for 
//testAddInteger and testReverse passed.
//Parts not working:add(int) it still allows additions once the array is full, the j unit didn't pass this test
//. Finally testReverse didn't work because I had trouble with thinking of the logic to test.






public class ArrayUtility implements UtilityInterface<Integer> {
	
	
	private Integer [] array;
	public static final int DEFAULT_CAPACITY = 10;
	private int last;
	
	public ArrayUtility() {
		array = new Integer[DEFAULT_CAPACITY];
		last = 0;
	}
	
	public ArrayUtility(int capacity) {
		array = new Integer[capacity];
		last = 0;
	}
	
//Complete------------------------------------------------
	@Override
	public boolean add(Integer anElement) {
		
		if(last == array.length) {
			System.out.println("Array is full!");
			return false;
		}
		for(int i = 0; i < array.length; i++) {
			if(array[i]==null) {
				array[last] = anElement;
				last++;
				return true;
			}
		}
		return false;
		
		
	}

	
//Needs fixing for null pointers
	@Override
	public boolean add(Integer anElement, int index) {
		if(last == array.length) {
			System.out.println("Array is full!");
			return false;
		}
		
		if(index>array.length) {
			return false;
		}

		
	    for(int i=0; i< array.length-1; i++) {
	        if (i == index){
	            for (int j = array.length-1; j >= index; j-- ){
	            	 array[j]= array[j-1];
	            }

	            array[index]=anElement;
	            return true;
	        }
	    }
	    return false;
	    }
	
	
	
	
//works
	@Override
	public void clear() {
		for(int i=0; i< last; i++) {
			array[i]=null;
		}last=0;
		
	}

	
	//check over
	@Override
	public boolean contains(Integer anElement) {
		
		if(isEmpty()) {
			return false;
		}
		
		for(int i=0; i< last; i++) {
			if(array[i].equals(anElement)) {
				return true;
			}
		}
		return false;
	}

	
	
	
	@Override
	public Integer get(int index) {
		if(isEmpty()) {
			return null;
		}
		
		if(index > last) {
			return null;
		}
		if(!(array[index].equals(null))) {
			return array[index];
		}
		return null;
	}

	
	
	
	//works
	@Override
	public int getCurrentSize() {
		return last;
	}

	
	//works
	@Override
	public int getFrequencyOf(Integer anElement) {
		int numOccurance = 0;
		for(int i=0; i< last; i++) {
			if(array[i].equals(anElement)) {
				numOccurance++;
			}
		}
		return numOccurance;
	}

	@Override
	public int indexOf(Integer anElement) {
		if(isEmpty()) {
			return -1;
		}
		
		for(int i=0; i< last; i++) {
			if(array[i].equals(anElement)) {
				return i;
			}
		}
		return -1;
	}

	
	//done
	@Override
	public boolean isEmpty() {
		if (last > 0) { 
			return false; 
		} else {
			return true;
		}
	}

	
	@Override
	public boolean remove(Integer anElement) {
		if(isEmpty()) {
			return false;
		}

		for(int i = 0; i < last; i++) {
			if(array[i]==anElement){
			for(int j = i; j < last-1; j++) {
			   int temp;
			   temp = array[j];
			   array[j] = array[j+1];
			   array[j+1] = temp;
			}
			array[last-1] = null;
			last--;
			return true;
			}
		}
		return false;
	}
	

	@Override
	public boolean removeFirst() {
		if(isEmpty()) {
			return false;
		}
		
		
		for(int i = 0; i < last-1; i++) {
			   int temp;
			   temp = array[i];
			   array[i] = array[i+1];
			   array[i+1] = temp;
			}
			array[last-1] = null;
			last--;
			return true;
	}

	
	
	@Override
	public boolean removeLast() {
		if(isEmpty()) {
			return false;
		}
		if(last!=0) {
			array[last-1]=null;
			last--;
			return true;
		}
		return false;
	}
	
	

	@Override
	public boolean removeMiddle() {
		if(isEmpty()) {
			return false;
		}
		
		if(last==1) {
			removeFirst();
			return true;
		}
		
		for(int i = (last-1/2); i < last-1; i++) {
			  int temp = array[i];
			   array[i] = array[i+1];
			   array[i+1] = temp;
			}
			array[last-1] = null;
			return true;
	}
	
	


	@Override
	public void reverse() {
		for(int i = 0; i < array.length/2 ; i++) {
			int temp = array[i];
			array[i] = array[array.length - i - 1];
			array[array.length - i - 1] = temp;
		}
		
	}
	
	
	
	
	
	
	
	public void printArray() {
		for(int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}

}
