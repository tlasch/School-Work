import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayUtilityTester {

	@Test
	public void testAddInteger() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		//add 10 items to the container
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		
		//adding one more after hitting max capacity
		assertFalse(array1.add(19));
		assertEquals(10, array1.getCurrentSize());
		assertFalse(array1.contains(19));

	}

	@Test
	public void testAddIntegerInt() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		//add 10 items to the container
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i,i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		
		//adding one more after hitting max capacity
		assertFalse(array1.add(19,11));
		assertFalse(array1.contains(19));
	}

	@Test
	public void testClear() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		array1.clear();
		assertEquals(0, array1.getCurrentSize());
		
		//add 10 items to the container
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}

		array1.clear();
		assertEquals(0, array1.getCurrentSize());
		
		assertFalse(array1.contains(19));
	}

	@Test
	public void testContains() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		assertFalse(array1.contains(1));
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		assertTrue(array1.contains(9));
		
		}

	@Test
	public void testGet() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		assertEquals(null,array1.get(0));
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		
	}

	@Test
	public void testGetCurrentSize() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		assertEquals(0,array1.getCurrentSize());
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		assertEquals(10,array1.getCurrentSize());
		
		
	}

	@Test
	public void testGetFrequencyOf() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		assertEquals(1,array1.getFrequencyOf(1));
	}

	@Test
	public void testIndexOf() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		assertEquals(0,array1.indexOf(1));
		
		
	}

	@Test
	public void testIsEmpty() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		assertFalse(array1.isEmpty());
	}

	
	
	@Test
	public void testRemove() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		assertFalse(array1.remove(0));
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		

		assertTrue(array1.remove(10));
		
	}

	@Test
	public void testRemoveFirst() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		assertFalse(array1.removeFirst());
		
		assertTrue(array1.add(1));
		assertEquals(1, array1.getCurrentSize());
		assertTrue(array1.contains(1));
		assertFalse(array1.isEmpty());
		
		assertTrue(array1.removeFirst());
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		assertTrue(array1.removeFirst());
	}

	
	@Test
	public void testRemoveLast() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		assertFalse(array1.removeLast());
		
		assertTrue(array1.add(1));
		assertEquals(1, array1.getCurrentSize());
		assertTrue(array1.contains(1));
		assertFalse(array1.isEmpty());
		
		assertTrue(array1.removeLast());
		
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		
		assertTrue(array1.removeLast());
		
	}

	@Test
	public void testRemoveMiddle() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		assertFalse(array1.removeMiddle());
		
		assertTrue(array1.add(1));
		assertEquals(1, array1.getCurrentSize());
		assertTrue(array1.contains(1));
		assertFalse(array1.isEmpty());
		
		assertTrue(array1.removeMiddle());
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		assertTrue(array1.removeMiddle());
		
	}

	@Test
	public void testReverse() {
		ArrayUtility array1 = new ArrayUtility();
		assertEquals(0, array1.getCurrentSize());
		assertTrue(array1.isEmpty());
		
		
		assertTrue(array1.add(1));
		assertEquals(1, array1.getCurrentSize());
		assertTrue(array1.contains(1));
		assertFalse(array1.isEmpty());
		
		
		for(int i = 1; i <=10; i ++) {
			assertTrue(array1.add(i));
			assertEquals(i, array1.getCurrentSize());
			assertTrue(array1.contains(i));
			assertFalse(array1.isEmpty());
		}
		
		array1.reverse();
		
		assertEquals(0,array1.contains(10));
		
		
		
	}

}
