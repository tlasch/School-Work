
public class ArrayUtilityDriver {

	public static void main(String[] args) {
		ArrayUtility array1 = new ArrayUtility();
		
		//testing getting size of empty array
		System.out.println(array1.getCurrentSize()==0);
		
		//testing removing from empty array not possible
		System.out.println(array1.remove(0)==false);
		
		//testing removing first from empty array not possible
		System.out.println(array1.removeFirst()==false);
		
		
		//testing removing Middle from empty array not possible
		System.out.println(array1.removeMiddle()==false);
		
		
		//testing removing Last from empty array not possible
		System.out.println(array1.removeLast()==false);
		
		
		
		
		
		
		
		
		//adding to the array
		
		array1.add(1);
		array1.add(2);
		array1.add(3);
		array1.add(4);
		array1.add(5);
		array1.add(6);
		array1.add(7);
		array1.add(8);
		array1.add(9);
		array1.add(10);
		//testing adding an extra
		array1.add(11);
		array1.add(6000);
		array1.printArray();
		System.out.println("****************************");
		System.out.println(array1.getCurrentSize());
		
		
		//testing remove certain number
	    array1.remove(4);
	    
	
	    
//		array1.printArray();
//		System.out.println("-----------------------------------------");
//		array1.printArray();
//		System.out.println("-------------Add Index----------------------------");
//		System.out.println("Add index: " + array1.add(600,3));
//		array1.printArray();
	    
	    
		
		
		


		
		
		//Testing frequency, contains, get, index of, and remove first
		System.out.println("frequency " + array1.getFrequencyOf(5));
		System.out.println("frequency " + array1.getFrequencyOf(0));
		System.out.println("contains " + array1.contains(5));
		System.out.println("get " + array1.get(100));
		System.out.println("Index Of " + array1.indexOf(4));
		System.out.println("before remove first");
		array1.printArray();
		System.out.println("Remove First " + array1.removeFirst());
		System.out.println("after remove first");
		array1.printArray();
		
		ArrayUtility array2 = new ArrayUtility();
		
		
		array2.add(1);
		array2.add(2);
		array2.add(3);
		array2.add(4);
		array2.add(5);
		array2.add(6);
		array2.add(7);
		array2.add(8);
		array2.add(9);
		array2.add(10);
		

		//testing remove last
		System.out.println("before remove last");
		array2.printArray();
		System.out.println("Remove LAst " + array2.removeLast());
		System.out.println("after remove last---------");
		array2.printArray();
		
		
		System.out.println("-------------------test remove middle----------------------");
		array2.printArray();
		System.out.println("Remove Middle " + array1.removeMiddle());
		array2.printArray();
		
		ArrayUtility array3 = new ArrayUtility();
		
		
		array3.add(1);
		array3.add(2);
		array3.add(3);
		array3.add(4);
		array3.add(5);
		array3.add(6);
		array3.add(7);
		array3.add(8);
		array3.add(9);
		array3.add(10);
		
		array3.printArray();
		array3.reverse();
		System.out.println("-----------Testing reverse--------------");
		array3.printArray();
		

		

	}

}
