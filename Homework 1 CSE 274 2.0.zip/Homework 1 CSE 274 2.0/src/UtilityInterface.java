/**
* Allows for the required methods to be included into the array utility class
*
* @param recieves the object t
*/
public interface UtilityInterface<T>{
	
	
	//working---------------------------------------
	/**
	* allows the user to add to the array a certain element
	* 
	* @param the element that is being added
	* @return true or false of whether the element was added
	*/
	public boolean add(T anElement);
	
	/**
	* allows the user to add to the array a certain element, adds at specific index
	* and then shifts the rest of the elements in the array after the index over
	* 
	* @param the element that is being added, as well as the index
	* @return true or false of whether the element was added
	*/
	public boolean add(T anElement, int index);
	
	//working---------------------------------------
	/**
	* clears the array if not already empty
	*/
	public void	clear();
	
	//working---------------------------------------
	/**
	* shows if the array contains a certain element
	* 
	* @param the element that is being searched for
	* @return true or false of whether the element was contained
	*/
	public boolean contains(T anElement);
	
	
	//working---------------------------------------
	/**
	* gets the element at a certain index of our array
	* 
	* @param the index of the element being searched for
	* @return the element as the index
	*/
	public T	get(int index);
	
	//working---------------------------------------
	/**
	* gets the current number of elements in the array
	* 
	* @return the number of elements in the array
	*/
	public int getCurrentSize();
	
	
	
	//working---------------------------------------
	/**
	*gets the frequency of a certain element in the array
	* 
	* @param the element being searched for
	* @return the number of times the element is in the array
	*/
	public int getFrequencyOf(T anElement);
	
	/**
	* searches through the array for the index of a certain element
	* 
	* @param the element being searched for
	* @return the index in the array of the element being searched for
	*/
	
	
	public int indexOf(T anElement);

	
	
	
	
	//working---------------------------------------
	/**
	* looks to see if the array is empty
	* 
	* @return true or false of whether the array is empty
	*/
	public boolean isEmpty();
	
	
	
	//working---------------------------------------
	/**
	* allows the user to remove a certain element from the array and then reorders the
	* number of elements accordingly
	* 
	* @param the element that is being removed
	* @return true or false of whether the element was removed
	*/
	public boolean remove(T anElement);
	

	/**
	* allows the user to remove the first element from the array and re arrange
	* the array elements correctly
	* @return true or false of whether the first element was removed
	*/
	public boolean removeFirst();
	
	//working---------------------------------------
	/**
	* allows the user to remove the last element from the array
	* @return true or false of whether the last element was removed
	*/
	public boolean removeLast();
	
	
	/**
	* allows the user to remove the middle element from the array
	* and then reorder the array elements afterwards
	* @return true or false of whether the middle element was removed
	*/
	public boolean	removeMiddle();
	
	
	//done
	/**
	*reverses the elements in an array
	*/
	public void	reverse();
	
}
